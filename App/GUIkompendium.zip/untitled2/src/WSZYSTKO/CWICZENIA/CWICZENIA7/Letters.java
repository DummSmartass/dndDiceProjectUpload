package WSZYSTKO.CWICZENIA.CWICZENIA7;

import java.util.ArrayList;
import java.util.Iterator;

public
class Letters
extends Thread
implements Iterable<Thread>
{
    ArrayList<Thread> thready = new ArrayList<Thread>();

    public Letters(String s)
    {
        for (char c : s.toCharArray())
        {
            Thread thread =
                new Thread
                (
                    ()->
                    {
                        while (!Thread.interrupted())
                        {
                            System.out.print(c);
                            try
                            {
                                sleep(1000);
                            }
                            catch (InterruptedException e) {}
                        }
                    }
                );

            thread.setName("Thread "+c);

            thready.add(thread);
        }

    }

    @Override
    public void run()
    {
        for (Thread thread: thready)
        {
            thread.start();
        }
    }


    @Override
    public Iterator<Thread> iterator()
    {
        return thready.stream().iterator() /*.iterator()*/;
    }

    public void stops()
    {
        //zatrzymanie każdego threada
        for (Thread thread:thready)
        {
            thread.stop();
        }
    }
}
