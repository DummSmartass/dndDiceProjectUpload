package WSZYSTKO.CWICZENIA.CWICZENIA4;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Hailstone implements Iterable<Integer>/*iterable pozwala iterować po obiekcie tej klasy*/, Iterator<Integer>/*to smao*/ {

    //nie wiem czemu nie mogę siężadnego pozyć

    private int start;

    public Hailstone(int start){
        this.start = 2*start;
    }

    //metody z interfacu iterator(po intach)
    @Override
    public Integer next(){
        if(!hasNext())
            throw new NoSuchElementException();//rzucanie customowych errorów

        //przechodzi krok i ustawia start na kolejną w artość
        if(start % 2 == 0) start /= 2;
        else start = 3*start + 1;

        //zwraca kolejną wartośc
        return start;
    }
    // sprawdza czy zmienna nie jest 1
    @Override
    public boolean hasNext(){
        return start != 1;
    }

    //iterator zwrac kolejny element
    // metoda z interfacu iterator(po intach)
    @Override
    public Iterator<Integer> iterator(){
        return this;
    }
}
