package WSZYSTKO.CWICZENIA.CWICZENIA4;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.Function;

public class z4 {

    static
    <T/*dowolna zmienna Typu T*/, R extends Comparable<R> /*R rozszerzająca Comparable dla zmiennej typu R*/> /* zapisanie, że wystąpi zmienna przyjmująca dowolną zmienną generyczną T jak i zmienną typu R rozszerzającego Comparable */
    Comparator<T> /*zwraca komparator*/ comCmp(Comparator<T> com /*zmienna typu konmparator*/, Function<T, R> fun/*obiek rozszerzający Function<T,R> dla T i R posiada niezbędnądo nadpisani applay*/)
    {
        //zwraca wynik lambdy(lambda ni musi niczego nadpisywać)
        return (p1, p2) ->
        {
            // porównuje za pomocą komparatora podane zmienne
            int d = com.compare(p1, p2);
            //jeżeli nie jest w stanie zdeterminować którą wybra c
            if(d != 0) return d;

            //porównuje wyniki podanej funkcji której wyniki rozszerzają comparable
            return fun.apply(p1).compareTo(fun.apply(p2));
        };
    }

    //wypisuje tablice dowolnych elementów
    static <T> void printArray(String title, T[] tab){
        System.out.println("\t*** " + title + " ***");
        for(int i = 0; i < tab.length; i++){
            System.out.println(tab[i]);
        }
    }

    public static void main(String[] args)
    {
        //Zadanie 1
        int ini = 77031, count = -1, maxel = 0;
        Hailstone hailstone = new Hailstone(ini);
        for (int h : hailstone)
        {
            if (h > maxel) maxel = h;
            ++count;
        }
        System.out.println(ini + " " + count + " " + maxel);

        //Zadanie 2
        Person[] arr = {
                new Person("Eve", 43),
                new Person("Joe", 34),
                new Person("Kim", 30),
                new Person("Joe", 25),
                new Person("Kim", 20),
                new Person("Eve", 27)
        };

        Comparator<Person> cmp = comCmp
        (
                // komparator porównuje imionanadpisany lambdą
                (p1, p2) -> p1.getName().compareTo(p2.getName()),

                // Funkcja? zwracająca wiek osoby, nie iwedziałem, że tak się da
                Person::getAge
        );

        //array posortowany z pomocątego comparatora
        Arrays.sort(arr, cmp);
        System.out.println(Arrays.toString(arr));

        //Zadanie 3
        Person1[] persons =
        {
                new Person1("Max",  Sex.M, Size.XL, Country.NL),
                new Person1("Jan",  Sex.M, Size.S,  Country.PL),
                new Person1("Eva",  Sex.F, Size.XS, Country.NL),
                new Person1("Lina", Sex.F, Size.L,  Country.DE),
                new Person1("Mila", Sex.F, Size.S,  Country.DE),
                new Person1("Ola",  Sex.F, Size.M,  Country.PL)
        };

        Comparator<Person1> sexThenSize = (p1, p2) -> p1.getSex().compareTo(p2.getSex());
        Arrays.sort(persons, sexThenSize);
        printArray("Persons by sex and then size", persons);

        Arrays.sort(persons, (p1, p2) -> p1.getSize().compareTo(p2.getSize()));
        printArray("Persons by size and then name", persons);

        Country[] countries = Country.values();
        Arrays.sort(countries, (c1, c2) -> c2.compareTo(c1));
        printArray("Countries by name", countries);
    }
}

class Person {
    String name;
    int age;

    Person(String n, int a) {
        name = n;
        age = a;
    }

    String getName() { return name; }
    int getAge() { return age;}

    @Override
    public String toString() {
        return name + "(" + age + ")";
    }
}

enum Sex {M, F};
enum Size {XS, S, M, L, XL};
enum Country {PL, NL, DE};

class Person1{
    private String name;
    private Sex sex;
    private Size size;
    private Country country;

    Person1(String name, Sex sex, Size size, Country country){
        this.name = name;
        this.sex = sex;
        this.size = size;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public Sex getSex() {
        return sex;
    }

    public Size getSize() {
        return size;
    }

    public Country getCountry() {
        return country;
    }

    @Override
    public String toString(){
        if(country == Country.PL)
            return name + "(" + sex + ", " + size + ", " + "Polska" + ")";
        else if(country == Country.NL)
            return name + "(" + sex + ", " + size + ", " + "Nederland" + ")";
        else
            return name + "(" + sex + ", " + size + ", " + "Deutschland" + ")";
    }
}