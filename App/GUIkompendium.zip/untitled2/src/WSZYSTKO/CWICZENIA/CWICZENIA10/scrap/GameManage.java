package WSZYSTKO.CWICZENIA.CWICZENIA10.scrap;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class GameManage extends JFrame implements MouseListener, KeyListener
{

    public boolean fill = false;
    public String shapes[] = {"Square","Circle"};
    public Color colors[] = {Color.RED,Color.GREEN,Color.ORANGE};

    @Override
    public void mousePressed(MouseEvent e)
    {
        if(e.getButton()==1)
        {
            int ex=e.getX();
            int ey=e.getY();

            Squares squares = new Squares(ex,ey,fill,colors[0],shapes[0]);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}





//     boolean end = false;
//     List<Squares> kwadraty = new LinkedList<>();
//     Difficulties difficulty = Difficulties.medium;
//     int ilepkt=0;
//     int minpkt=20;
//     JLabel jl1;



    public void paint(Graphics g)
    {
        super.paint(g);

//        if(end) return;
//
//        for (int i = 0; i < kwadraty.size(); i++)
//        {
//            kwadraty.get(i).draw(g);
//
//            if(kwadraty.get(i).escaped(445))
//            {
//                kwadraty.remove(kwadraty.get(i));
//                i--;
//                newSquare();
//            }
//        }
//        try {Thread.sleep(30);}
//        catch (InterruptedException e){}

        this.repaint();
    }

//    public  void newSquare()
//    {
//        int x = (int)(Math.random()*360 + 1);
//        kwadraty.add(new Squares(x,-40,40,40));
//    }

    public GameManage()
    {
        addMouseListener(this);
        addKeyListener(this);

        // utworzenie frama--------------------------------------
        //JFrame jf1 = new JFrame();
        setName("Circles & Squares");
        setVisible(true);
        setPreferredSize(new Dimension(600,400));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        //-----------------------------------------------------------------

        // utworzenie tablicy wyników--------------------------------------
//        JPanel punkty = new JPanel();
//        jl1 = new JLabel("Current score: 0");
//        jl1.setHorizontalAlignment(SwingConstants.CENTER);
//        jl1.setPreferredSize(new Dimension(375,50));
//        jl1.setBorder(BorderFactory.createTitledBorder("Score"));
//        punkty.add(jl1, new GridLayout(1,1));
        //-----------------------------------------------------------------

        // utworzenie ekranu-----------------------------------------------
        JPanel ekran = new JPanel();
        ekran.setBackground(new Color(0,0,197));
        ekran.setPreferredSize(new Dimension(400,500));

//        JOptionPane vicoryLable = new JOptionPane("You won");
//        vicoryLable.setVisible(false);
//        JOptionPane defeatLable = new JOptionPane("You lost");
//        defeatLable.setVisible(false);

//        ekran.add(vicoryLable);
//        ekran.add(defeatLable);

        //-----------------------------------------------------------------

        //Operacje końcowe ------------------------------------------------
        add(ekran);
        //add(punkty,BorderLayout.SOUTH);
        pack();
        //-----------------------------------------------------------------

        //rozruch----------------------------------------------------------
        //for (int i = 0; i < difficulty.getValue(); i++) {newSquare();}
        //-----------------------------------------------------------------

        //Obsługa czasu----------------------------------------------------
//        Thread timer = new Thread(
//            ()->
//            {
//                try {
//                    Thread.sleep(60 * 1000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                end = true;
//                if (ilepkt >= minpkt * difficulty.getValue())
//                    vicoryLable.setVisible(true);
//                else
//                    defeatLable.setVisible(true);
//            }
//        );
//        timer.run();
        //-----------------------------------------------------------------
    }



    @Override
    public void mouseClicked(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}

}
