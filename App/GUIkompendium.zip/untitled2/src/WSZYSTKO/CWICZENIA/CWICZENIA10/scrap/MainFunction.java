package WSZYSTKO.CWICZENIA.CWICZENIA10.scrap;

//import javax.swing.*;
import WSZYSTKO.CWICZENIA.CWICZENIA10.scrap.GameManage;

public class MainFunction
{
    public static void main(String[] args)
    {
        GameManage gra = new GameManage();
    }
}

