package WSZYSTKO.CWICZENIA.CWICZENIA10.scrap;

import java.awt.*;
import java.util.Random;

public class Squares
{

    private int x;
    private int y;
    boolean fill;
    Color color;
    String shape;

    public Squares(int x, int y,boolean fill, Color color, String shape)
    {
        this.x = x;
        this.y = y;
    }

    public void draw(Graphics g)
    {
        g.setColor(color);
        int size = (int)(Math.random()*30+20);

        switch (shape)
        {
            case "Square":
                if(fill)
                    g.fillRect(x,y,size,size);
                else
                    g.drawRect(x,y,size,size);
                break;
            case "Circle":
                if(fill)
                    g.fillOval(x,y,size,size);
                else
                    g.drawOval(x,y,size,size);
                break;

            default: break;
        }
    }
}


