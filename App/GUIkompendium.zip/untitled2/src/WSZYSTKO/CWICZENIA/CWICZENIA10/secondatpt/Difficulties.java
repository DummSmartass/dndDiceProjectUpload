package WSZYSTKO.CWICZENIA.CWICZENIA10.secondatpt;

public enum Difficulties
{
    easy(3),
    medium(5),
    hard(7),
    veryHard(10),
    impossible(25);

    private int value;

    private Difficulties(int aValue)
    {
        this.value = aValue;
    }

    public int getValue(){
        return value;
    }
}
