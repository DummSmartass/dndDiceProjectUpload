package WSZYSTKO.CWICZENIA.CWICZENIA10.secondatpt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;
import java.util.List;

public class GameManage extends JFrame implements MouseListener, KeyListener
//klasa rozszerza Jframe, więc może go zastąpić
//klasa implementuje MouseListener więc może reagować na kliknięcia myszki
//lasa implementuje KeyListener więc może reagować na kliknięcia myszki
{
    //lista przechowuje obiekty do wyświetlania
     List<Squares> kwadraty = new LinkedList<>();

     //zmienne pomocnicze i trzymające potrzebne informacje
     boolean fill = false;
     String shape[] = {"square","circle"};
     Color colors[] = {Color.RED,Color.GREEN,Color.ORANGE};

     int shapekey=0;
     int colorkey=0;


     //funkcja paint, ta konkretna funkcja służy do rysowania, nie ma ona overrita, ale musi a=ona się tak nazywać
    public void paint(Graphics g)
    {
        //odpowiedzialne za podstawoew elementy takie jak kolor tła
        super.paint(g);

        //iterowanie po obiektach do narysowania i używanie funkcji draw do umieszczenia jej na grafice
        for (int i = 0; i < kwadraty.size(); i++)
        {
            kwadraty.get(i).draw(g);
        }

        //cooldown dla odświerzania(bez tego zużywa więcej mocy obliczeniowej i mruga)
        try {Thread.sleep(30);}
        catch (InterruptedException e){}

        //ponowne wykonanie paint(w praktyce jest to zapętlenie)
        this.repaint();
    }

    // mousePressed reaguje na użytkownika wciskającego klawisze myszki
    @Override
    public void mousePressed(MouseEvent e)
    {
        //mouse event to input z myszki

        //e.getButton() zwraca klawisz wybrany przez urzytkownika(1-lewy,2-prawy,3-kółko)
        if(e.getButton()==1)
        {
            //tak można uzyskać kordynatu myszki
            int ex=e.getX();
            int ey=e.getY();

            //randomizacja wielkości
            int size = (int)(Math.random()*30 + 20);

            //stworzenie kwadratu w oparciu o dane
            kwadraty.add(new Squares(ex,ey,size,fill,shape[shapekey],colors[colorkey]));
        }
    }

    // keyTyped reaguje na użytkownika wciskającego klawisze klwiatóry
    @Override
    public void keyTyped(KeyEvent e)
    {
        //keyEven to input z myszki

        //tak można uzyskać wartości charowe klawisza
        switch (e.getKeyChar())
        {
            case 'r':
                colorkey=0;
                break;
            case 'g':
                colorkey=1;
                break;
            case 'o':
                colorkey=2;
                break;
            case ' ':
                shapekey=(shapekey+1)%2;
                break;
        }
    }

    //keyPressed reaguje na użytkownika wciskającego(i przyciksającego) klawisze klwiatóry
    @Override
    public void keyPressed(KeyEvent e)
    {
        //część klawiszy nie ma odpowiedników charowych tak sięje sprawdza(mają własne funkcje)
        if(e.isShiftDown())
            fill=!fill;
    }

    //keyReleased reaguje na użytkownika przestającego wciskać dany klawisz
    @Override
    public void keyReleased(KeyEvent e)
    {
        if(e.isShiftDown())
            fill=!fill;
    }

    //konstruktor
    public GameManage()
    {
        //dodanie listenerów pozwala ich używać
        addMouseListener(this);
        addKeyListener(this);

        setVisible(true);
        setPreferredSize(new Dimension(600,450));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);

        JPanel ekran = new JPanel();
        //background możę być ustawiony customowycm kolorem
        ekran.setBackground(new Color(0,0,221));
        ekran.setPreferredSize(new Dimension(400,500));

        add(ekran,BorderLayout.CENTER);
        pack();
    }


    //nie wszystkie funkcje są potszebne
    @Override
    public void mouseClicked(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}


}
