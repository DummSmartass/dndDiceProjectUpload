package WSZYSTKO.CWICZENIA.CWICZENIA10.secondatpt;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;

public class MainFunction
{
    //wszystko opisane jest w funkcji customowej rozszerzającej jframe
    public static void main(String[] args)
    {
        GameManage gra = new GameManage();
    }
}

