package WSZYSTKO.CWICZENIA.CWICZENIA10.secondatpt;

import java.awt.*;

public class Squares
{

    private int x;
    private int y;
    private int size;
    private boolean fill;
    String shape;
    Color color;



    public Squares(int x, int y, int size,boolean fill,String shape,Color color)
    {
        this.x = x;
        this.y = y;
        this.size = size;
        this.fill=fill;
        this.shape=shape;
        this.color=color;
        //wczytanie wszystkich zmiennych
    }

    //funkcja draw służy do pisania
    public void draw(Graphics g)
    {
        //tak ustawia się kolor
        g.setColor(color);

        switch(shape)
        {
            case "circle":
            {
                if (fill)
                    g.fillOval(this.x, this.y, this.size, this.size);
                else
                    g.drawOval(this.x, this.y, this.size, this.size);
                break;
            }

            case "square":
            {
                if (fill)
                    g.fillRect(this.x, this.y, this.size, this.size);
                else
                    g.drawRect(this.x, this.y, this.size, this.size);
                break;
            }
        }
    }

}

