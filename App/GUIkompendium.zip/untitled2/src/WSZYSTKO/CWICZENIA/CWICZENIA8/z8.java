package WSZYSTKO.CWICZENIA.CWICZENIA8;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Set;

public class z8
{
    // swing
    static String oldText;
    public static void main(String[] args)
    {
        //zad1
        SwingUtilities.invokeLater
        (
            () -> createGUI() /*można nadpisać swing podając mu w tym miejscu funkcje*/
        );

        //zad2
        SwingUtilities.invokeLater
        (
            () -> createGUI2() /*można nadpisać swing podając mu w tym miejscu funkcje*/
        );

    }


    private static void createGUI()
    {
        JFrame frame = new JFrame("Okienko");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button1 = new JButton("Warsaw");
        JButton button2 = new JButton("Change title...");

        //można ustwić długość TextFielda
        JTextField textfield1 = new JTextField(20);

        // zmień text w tekstfieldzie na text z góźika
        button1.addActionListener(e -> textfield1.setText(button1.getText()));

        //po wciśnięciu entera czyli wyśłaniu aklci zmień nazwe góoźika
        textfield1.addActionListener(e -> button1.setText(textfield1.getText()));

        //zmień tytuł frama(więcej w funkcji na dole)
        button2.addActionListener(new ChangeTitle(frame, textfield1));

        //ogarnięcie lokalizacji
        JPanel panel = new JPanel();

        panel.add(button1);
        panel.add(button2);
        panel.add(textfield1);

        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static void createGUI2()
    {
        //jframe z nawą
        JFrame frame = new JFrame("WORDS");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // text area trzyma text
        JTextArea textArea= new JTextArea(20, 50);

        //jbuttony
        JButton button1 = new JButton("Back");
        JButton button2 = new JButton("Show words");


        button2.addActionListener
                (
            e ->
            {
                //pobranie textu z textarei
                //stworzenie backapu ytextu
                oldText = textArea.getText();

                // stworzenie w oparciu o text listy, elementy dizeleone są po znakach białych to co "\\P{L}" oznacza
                String[] words = textArea.getText().split("\\P{L}");

                Set<String> set = new HashSet<>();

                for(int i = 0; i < words.length; i++)
                {
                    //dodanie wszystkich słów do hasmapy
                    set.add(words[i].toLowerCase());
                }

                String str = "";
                for(String word : set)
                {
                    str = str + word + "\n";
                }
                //ustawienie koljnych słów pod sobą

                //zastąpienie text arei nowym śłowem
                textArea.setText(str);
            }
        );

        //załadowanie backapu
        button1.addActionListener(e ->
        {
            textArea.setText(oldText);
        });

        //dodanie góźików do panelu
        JPanel panel = new JPanel();
        panel.add(button1);
        panel.add(button2);

        //ustawienie layoutu i ustwienie elementów na ich miejscach
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.SOUTH);
        frame.add(textArea, BorderLayout.CENTER);

        //spakowanie wszystkeigo
        frame.pack();
        //ustawienie lokalizacji względnej na null co znaczy, że wszystko jest zcentrowane
        //można ustwić te zmienną na coś innego niż null i wtedy wszystko skupi się wokó tego elementu
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

//out of order
class ChangeTitle implements ActionListener
//klasa rozszerza actionListener więc może go zastąpić
{
    private JFrame frame;
    private JTextField textfield;

    //change title podłaćza frame i textfiekd podany z  zewnątrz
    public ChangeTitle(JFrame frame, JTextField textfield){
        this.frame = frame;
        this.textfield = textfield;
    }

    // nadpisanie akcji do wykonania
    @Override
    public void actionPerformed(ActionEvent e)
    {
        frame.setTitle(textfield.getText());
    }
}
