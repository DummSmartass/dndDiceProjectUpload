package WSZYSTKO.CWICZENIA.CWICZENIA2;

public interface Func {
    double apply(double x);

    //compose uniwersalnie łączy funkcje
    static Func compose(Func f, Func g)
    {

        // compose zwraca "klase" rozszerzającą interfejs z zainicjowaną funkcją applay stworząnąw oparciu na dwóch innych funkcjach tego typu zapewnionych
        return new Func()
        {
            public double apply(double x){
                return f.apply(g.apply(x));
            }
        };
    }
}
