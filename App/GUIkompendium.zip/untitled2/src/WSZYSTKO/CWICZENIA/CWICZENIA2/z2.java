package WSZYSTKO.CWICZENIA.CWICZENIA2;

import java.util.Arrays;

public class z2
{
    public static void main(String[] args)
    {
        Parabola fun1 = new Parabola(1, -1, 5./4);

        FunDD fun2 = new FunDD()
        {
            // inna funkcja niż parabola zainicjowana
            @Override
            public double fun(double x){
                return Math.sqrt(Math.pow(x-0.75, 2) + 1);
            }
        };

        // inny obiekt rozszerzający FunDD nadpisany tym razem lambdą
        FunDD fun3 = x -> x*x*(x-2);

        double min1 = FunDD.xminim(fun1, 0, 1);
        double min2 = FunDD.xminim(fun2, 0, 2);
        double min3 = FunDD.xminim(fun3, 0, 2);

        System.out.println("Res1: " + min1);
        System.out.println("Res2: " + min2);
        System.out.println("Res3: " + min3);
        System.out.println();


        //zad3

        String[] arr = {"Alice", "Sue", "Janet", "Bea"};
        //wypisanie tablei
        System.out.println(Arrays.toString(arr));

        // podanie do SFiltra obiektu klasy rozszerzającej interface
        String[] a1 = SFilter.filter(arr,new LenFilter(4));
        System.out.println(Arrays.toString(a1));

        //podanie obiektu nowego SFiltra i nadpisani na miejscu jego funkcji
        String[] a2 = SFilter.filter(arr, new SFilter(){
            //Zaczyna się na litere między A i D
            @Override
            public boolean test(String s){
                return(s.charAt(0) < 'D' && s.charAt(0) >= 'A');
            }
        });
        System.out.println(Arrays.toString(a2));

        //Stworzenie tablicy w oparciu o tablice i dostarczony lambdą(jedna metoda) obiekt rozszerzający interface SFilter
        String[] a3 = SFilter.filter(arr, s -> s.charAt(0) > 'H' && s.charAt(0) <= 'Z');
        System.out.println(Arrays.toString(a3));
    }
}
