package WSZYSTKO.CWICZENIA.CWICZENIA2;

@FunctionalInterface
interface SFilter
{

    //test do zdeterminowania czy string spełnia klase rozszerzającą ten interface
    boolean test(String s);

    //funkcja statyczna przyjmujące tablice stringów jak i obiekt rozszerzającuy Sfilter i zwracająca tablice zawierającą jedynie elementy spełniające warunke filtra
    public static String[] filter(String[] arr, SFilter filtr)
    {
        //pobranie długośic wymaganej
        int counter = 0;
        for(int i = 0; i < arr.length; i++)
        {
            //wykorzystanie testu, który nie jest tu jeszcze zainicjalizowany
            if(filtr.test(arr[i]))
            {
                counter++;
            }
        }

        //umieszaczenie w nowej tablicy tylko spełniające filter elementy
        String[] res = new String[counter];
        int j = 0;
        for(int i = 0; i < arr.length; i++){
            if(filtr.test(arr[i])){
                res[j] = arr[i];
                j++;
            }
        }

        //przesłanie nowej tablicy
        return res;
    }
}
