package WSZYSTKO.CWICZENIA.CWICZENIA2;

@FunctionalInterface
interface FunDD {

    // funkcja jest zaninicjalizowana w interfejsi, więć można ją wykonać na karzdymn obiekcie interfejsu
    double fun(double x);

    static double xminim(FunDD f, double a, double b){
        double min = a;
        for(double i = a; i <= b; i += Math.pow(10, -5))
        {
            //szuka najniższej wartości pomiędzy a i b z doklładnością do 0.00001
            if(f.fun(i) < f.fun(min))
                min = i;
        }
        return min;
    }
}
