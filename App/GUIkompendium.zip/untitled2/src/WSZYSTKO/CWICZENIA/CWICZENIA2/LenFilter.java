package WSZYSTKO.CWICZENIA.CWICZENIA2;

public class LenFilter implements SFilter
{
    private int minLen;

    //filtr minimalnej długości otrymuje zmienną
    public LenFilter(int minLen){
        this.minLen = minLen;
    }

    //filtr sprawdza czy wymaganie minimalnej długości jest spełnione
    @Override
    public boolean test(String s){
        return s.length() >= minLen;
    }
}
