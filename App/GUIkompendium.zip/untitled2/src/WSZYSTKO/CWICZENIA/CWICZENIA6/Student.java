package WSZYSTKO.CWICZENIA.CWICZENIA6;

public class Student {
    private String name;
    private String group;
    private int result;

    public Student(String name, String group, int result){
        this.name = name;
        this.group = group;
        this.result = result;
    }

    public String getGroup(){
        return group;
    }

    @Override
    public String toString(){
        return name + "(" + group + ")-" + result;
    }
}
