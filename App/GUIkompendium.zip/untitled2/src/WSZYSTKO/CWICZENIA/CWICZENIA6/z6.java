package WSZYSTKO.CWICZENIA.CWICZENIA6;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class z6 {
    public static void main(String[] args) throws IOException {
        //Zadanie 1
        //potok

        Files //otwrcie potoku do interpretowania plików
                .lines(Paths.get("src/WSZYSTKO/CWICZENIA/CWICZENIA6/list.txt"))//Paths.get() podaje pełnąścieżkę ze stringa//pobranie ścieżki i podzielenie ich na linie
                .map(p -> p.split(" "))//dla wszystkich linji podzieliść stringi według spacji i zmapowanie tego na liste zawierającą te araje
                .map(p -> new Student(p[0], p[1], Integer.parseInt(p[2])))// zmapowanie araji w liście na liste zawierająćą obiekty student
                .collect(Collectors.groupingBy(s -> s.getGroup())) // zebranie i zgrupowanie obuiektów w mapie ze względu na ich grupe i tym samym nadanie im klucza jakim jest grupa
                .forEach((k, v) -> System.out.println(k + " " + v)); // wypisanie klucza i zawartość każdego elementu mapy

        //Zadanie 2

        Random r = new Random();
        final int N = 10_000_000, M = 10;

        Stream //otwarcie streamu
                .generate(r::nextInt)//generowanie kolejnych elementów z podanego generatora( w tym przypadku Random())
                .limit(N)//ustawiamy limit wygenerowanych lementów na 10_000_000
                .collect(Collectors.groupingBy(l -> Math.abs(l) % M))// Math.abs(l) podaje wartość absolutną l, ostatecznie wszystko grupowane jest przez reszte z dzielenia przez 10
                .forEach((k, v) -> System.out.println(k + " -> " + v.size()));//wupisanie dla każdego elementu klucza iw artości

        //Zadanie 3
        //.getProperty może podaćścieżke do specyficznych rodzaji elementów
        String file = System.getProperty("user.home") +"/IdeaProjects/untitled3/src/WSZYSTKO/CWICZENIA/CWICZENIA6"+ "/CountWords.txt";

        int ch;
        FileInputStream fin = new FileInputStream(file);

        //Za pomocą nadpisania iterator można iterować po mapie
        for (Map.Entry<String, Integer> e : new Words(file))
            System.out.println(e.getKey() + " -> " + e.getValue());//wyświetlanie klucza i wartości kolejnych elementów
    }
}
