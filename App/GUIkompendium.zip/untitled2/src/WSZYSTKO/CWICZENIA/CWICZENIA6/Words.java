package WSZYSTKO.CWICZENIA.CWICZENIA6;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// \\P{L}+
public class Words implements Iterable<Map.Entry<String, Integer>>{

    private String file;
    private Map<String, Integer> map = new HashMap<>();

    public Words(String file) throws IOException
    {

        this.file = file;

        Files //otwrzenie pliku
                .lines (Paths.get(file)) // wuyciągnięcie linjji pliku
                .flatMap(p -> Stream.of(p.split("\\P{L}+")))// stworzenie płaskiej mapy ze stramu stworzonego z kolejnych list stworzonych z kolejnych linijek podzielonych regexem znaków iałych
                .map(s -> s.toLowerCase())//zmapowanie wszystkich elementów do lowercase
                .collect(Collectors.groupingBy(s -> s))//grypowanie po nazwie
                .forEach((k, v) -> map.put(k, v.size()));//dla każdego (klucza grupowania, wartości) do mapy zostaje dodany
    }

    @Override
    public Iterator<Map.Entry<String, Integer>> iterator()
    {
        return map.entrySet().iterator(); // map.entrySet() zamienia mape na możliwt do iterowania zestawów(setów)   //.iterator tworzy iterator oparty na tym zestawie
    }

}
