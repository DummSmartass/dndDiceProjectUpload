package WSZYSTKO.CWICZENIA.CWICZENIA13;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Main2 extends Application {

    @Override
    public void start(Stage stage) throws Exception
    {
        //Hbox rozkłada swoje elementy choryzontalnie
        HBox root = new HBox();
        Scene scene = new Scene(root, 300, 275);
        stage.setScene(scene);
        stage.setTitle("CHAT");

        //tak można ustawiać chatOkna(te na dole)
        ChatWindow ch1 = new ChatWindow();
        ChatWindow ch2 = new ChatWindow();

        root.getChildren().addAll(ch1, ch2);

        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class ChatWindow extends VBox
//Chat okna rozszerzają wiboxa więć będą miały pionowy aligment i będąc per saldo javafx odpowiednikiem jpanelu można je też wstawiać do roota
{
    //tak deklaruje się textField w javafx
    public TextField tf = new TextField();

    //tak deklaruje się textarea w javafx
    public TextArea ta = new TextArea();

    //służy do przechwoywania wszystkich okien do których ma być wysłany text
    public ArrayList<ChatWindow> listaOkien = new ArrayList<>();

    public void addWindow(ChatWindow chatWindow)
    {
        listaOkien.add(chatWindow);
    }

    public ChatWindow()
    {

        //tak deklaruje się góźiki w javafx
        Button b = new Button("Send");
        listaOkien.add(this);

        //tak dodaje się co ma się stać po wciśnięciu góźika
        b.setOnAction
        (
            e->
            {
                //iteruje po oknach
                for (ChatWindow ch:listaOkien)
                {
                    //dodaje do wszystkich okien wiadomosći
                    ch.ta.appendText("\n"+this.tf.getText());

                    //czyści textField aby ułatwić użytkowanie
                    this.tf.clear();
                }
            }
        );

        // Hbox nie musi być w roocie działa podobine do jpanelu
        HBox hBox = new HBox();
        hBox.getChildren().addAll(tf, b);

        // na dole w centum(odnosi się to do zestawu textfield + góźik)
        hBox.setAlignment(Pos.BOTTOM_CENTER);

        // tak się robi scrollpane
        ScrollPane scrollPane = new ScrollPane(ta);
        //tak ustawia się pionowy i poziomy scrollbar
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        //dodawanie lementów
        this.getChildren().addAll(scrollPane, hBox);
        this.setAlignment(Pos.CENTER);
    }

}