package WSZYSTKO.CWICZENIA.CWICZENIA13;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

//podłączenie komponentów javafx do pliku
//--module-path "C:\Program Files\Java\javafx-sdk-18.0.1\lib" --add-modules javafx.controls,javafx.fxml
//gdzie "C:\Program Files\Java\javafx-sdk-18.0.1\lib" zastąpić naleźy lokalizacją załączonych plków jafx

public class Main extends Application
//klasa może rozszerzać aplikacje javafxową co zamienia klase w generator aplikacji okienowej
{

    //nadpisanie startu aplikacji okienkowej
    @Override
    //start pszysjmuje stage jako podstawe aplikacji oraz jest gotowe do rzucania wyjątków
    public void start(Stage stage) throws Exception
    {
        //jądro typu Vbox pozwal stawiać obiekty Vertykalnie V-box
        VBox root = new VBox();

        // scena przyjmuje jądro i wymiary, scena jest ojak okno na zawartość jądra, ma konkretą wielkość ale nie w nim trzymane są widziane obiekty
        Scene scene = new Scene(root, 300, 275);

        //wypełninie koloerem
        scene.setFill(Color.BLUE);

        //stage służy do pokazania sceny
        stage.setScene(scene);

        //nazwanie staga która jest persaldo samą aplikacja
        stage.setTitle("Snowman");

        //Tworzenie obiektów będących kołami wypełnionymi na biało
        //warto pamiętać, żeby nie pom,ylić obiektów z ich odpowiednikami z poza javafxa
        Circle c1 = new Circle();
        c1.setFill(Color.WHITE);
        Circle c2 = new Circle();
        c2.setFill(Color.WHITE);
        Circle c3 = new Circle();
        c3.setFill(Color.WHITE);

        //tak dodaje isę obiekty do roota, najlepiej szystkie na raz
        root.getChildren().addAll(c1, c2, c3);

        //tak ustawia się w jaki sposób lementy mają być ułożone (w tym przypadku na środku)
        root.setAlignment(Pos.CENTER);

        //tak można połączyć wartości wielkości obiektów do innych zmiennych
        //od terz wielkość promienia c1 pozosyanie równa wysokości podzielonej na 12 jest związana z wysokością i kiedy ona się zmieni promień się dopasuje
        c1.radiusProperty().bind(scene.heightProperty().divide(12));
        c2.radiusProperty().bind(scene.heightProperty().divide(6));
        c3.radiusProperty().bind(scene.heightProperty().divide(4));

        //stage.show wyświetla wszystko
        stage.show();
    }

    public static void main(String[] args)
    {
        //launcg(args) uruchamia metode start
        launch(args);
    }
}
