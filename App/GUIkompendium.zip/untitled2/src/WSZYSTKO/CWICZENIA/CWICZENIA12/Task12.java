package WSZYSTKO.CWICZENIA.CWICZENIA12;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Task12 {
    public static void main(String[] args)
    {
        //wywoływanie wielu aplikacji jednocześnie
        SwingUtilities.invokeLater(() -> okno1());
        SwingUtilities.invokeLater(() -> okno2());
        SwingUtilities.invokeLater(() -> okno3());
    }

    static public void okno1()
    {
        JFrame frame = new JFrame("Snowman");

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        MyPanel panel = new MyPanel();

        //ustawienie wielkości panelu
        panel.setPreferredSize(new Dimension(300, 300));
        // dodanie do centrum frama panelu
        frame.add(panel, BorderLayout.CENTER);

        //spakowanie u ustawienie widocznosci na tak
        frame.pack();
        frame.setVisible(true);
    }

    static class MyPanel extends JPanel
    // klasa rozszerza JPanel więc mozę być użyty jako takowy
    {
        //nieobowiązkowe nadpisanie paintComoponentu
        //paintComponetnt uruchamia się ałtomatyczne po dodaniu panelu i rysuje po nim, paint component utuchamia się również za każdym razem kiedy elementy obrazku mają ulec zmianie
        @Override
        public void paintComponent(Graphics g)
        //g jest lokalizacją w tym przypadku panelem
        {
            //odwołanie się do klasy nadrzędnej (obowiązkowwa głupota)
            super.paintComponent(g);

            //ustawienie bacgroundu i koloru do rysowania
            this.setBackground(Color.BLUE);
            g.setColor(Color.WHITE);

            // tak można pobrać wielkośc panelu od wewnątrz
            int height = this.getHeight();
            int width = this.getWidth();

            // tak wypełnia się owale w zależności od zmiennych opartych na wartościach zmiennych
            g.fillOval(width/2-(height/12), 0, height/6, height/6);
            g.fillOval(width/2-(height/6), height/6, height/3, height/3);
            g.fillOval(width/2-(height/4), height/2, height/2, height/2);
        }
    }

    static public void okno2()
    {
        JFrame frame = new JFrame("LIST");

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JTextField textField = new JTextField();

        //obiekty Jlist służą do łatwego wyświetlania zawartości list w aplikacjach okienkowych swinga
        //utworznenie listy opartj na nowym obiekcie customowego modelu
        JList<String> jList = new JList<>(new MyModel());

        // wyciągnięcie do zewnętrznej zmiennej wzmiankowanego modelu aby dało się na nim łatwo operować
        //.getModel zwraca model
        //(MyMOdel) pomaga w rozpoznaniu oniekyu jako będącego obiektem tej klasy
        MyModel model = (MyModel)(jList.getModel());

        // jscrollpane pomoże przechować dowolnie długą listeo
        JScrollPane scrollPane = new JScrollPane(jList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        //do textfielda można dodać actionListenera uruchamianego przy wćiśnięciu enera
        textField.addActionListener(e ->
        {
            //podzielenie textu z textfielda na liste
            String[] text = textField.getText().split("\\s+");

            //zaprogramowanie komend

            if(text[0].equals("add")) {
                model.add(text[1]);
            }

            else if(text[0].equals("del")) {
                model.del(text[1]);
            }

            else if(text[0].equals("quit"))
                System.exit(0);

            //wyrzucienie błędu w przypadku nierozpoznania komendy
            else
                //JOptionPane.showMessageDialog wyśiwetla wiadomosć
                // argumenty (lokalizacja, text, tytuł, rodzaj)
                //JOptionPane.WARNING_MESSAGE powoduje wyśiwetlenie wiadomości w formie erroru
                JOptionPane.showMessageDialog(frame, "Invalid command", "WARNING", JOptionPane.WARNING_MESSAGE);
        });

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(textField, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    static class MyModel extends AbstractListModel<String>{
        ArrayList<String> list = new ArrayList<>();

        //w modelu musząwystępować nadpisane funkcje umożliwaijąće jego wyśwoietlenie
        @Override
        public int getSize() {
            return list.size();
        }
        @Override
        public String getElementAt(int index) {
            return list.get(index);
        }

        //funkcja do dodawania
        public void add(String str)
        {
            //przechodzi przez liste
            for(String s : list)
            {
                //jeżeli znajdzie powtórke wyrzuca błlą
                if(s.equals(str))
                {
                    JOptionPane.showMessageDialog( JOptionPane.getRootFrame(),"Entry \"" + str + "\" already exists", "WARNING", JOptionPane.WARNING_MESSAGE);

                    //i kończy wykonywanie funkcji
                    return;
                }
            }

            // w przeciwnym przypadku dodaje element do listy
            list.add(str);

            // pozwala jliście działać prawidłowo i musi być odświerzany kiedy ilość elementów się zmienia
            // pokazuje on CHYBA zakre dostepnych elementów
            fireIntervalAdded(this, 0, list.size());
        }

        //funkcja do usówania
        public void del(String str)
        {
            boolean exists = false;

            int index = 0;

            //jeżeli znaleziony zostanie taki string w liście ustaw zmienną pomocniczą na true
            for(int i = 0; i < list.size(); i++)
            {
                if(list.get(i).equals(str))
                {
                    index = i;
                    exists = true;
                    break;
                }
            }

            //jeżeli zmienna pomocnicza jest prawdziwa to usuń znaleziony index z listy i jązaktualizuj
            if(exists)
            {
                list.remove(index);
                fireIntervalRemoved(this, 0, list.size());
            }

            else
                JOptionPane.showMessageDialog( JOptionPane.getRootFrame(),"Entry doesn't exists", "WARNING", JOptionPane.WARNING_MESSAGE);

        }
    }


    static public void okno3()
    {
        JFrame frame = new JFrame("Resizable square");

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel helpanel = new JPanel();

        JLabel jl1 = new JLabel("Size od square");
        //dodanie slidera
        //Jsliderjest horyzontalny zaczyna się na 0 kończy na 100 i ma domyślnie 50
        JSlider js1 = new JSlider(JSlider.HORIZONTAL,0,100,50);
        js1.setPaintTicks(true);// wypisuj małe kreski
        js1.setMinorTickSpacing(1);//częstotliwość małych kresek
        js1.setPaintTrack(true);//wypisuj duże kreski
        js1.setMajorTickSpacing(10);//częstotliwość dużych kresek
        js1.setPaintLabels(true);//napisz nadużych kreskach wartości

        //dodałem customowy panel przyjmujący slider jako argument
        MyPanel2 panel = new MyPanel2(js1);
        panel.setPreferredSize(new Dimension(300, 300));

        //dodałem changelistenera do jslider
        //uruchamia się on wtedy kiedy wartość na sliderze zostanie zmieniona
        js1.addChangeListener
        (
            //nadpisanie lambdą
            e->
            {
                //można wywołać paint component z zwenątrz
                //aby go wywołać trzeba urzyć jako arhumentu grafiki wyciągniętej z obiektu na którym się go wywołuje
                panel.paintComponent(panel.getGraphics());
            }
        );


        helpanel.add(jl1);
        helpanel.add(js1);

        //layout można ustawić(zmienić) po utworzeniu np panelu
        helpanel.setLayout(new GridLayout(2,0));

        frame.add(helpanel,BorderLayout.SOUTH);
        frame.add(panel, BorderLayout.CENTER);

        //spakowanie u ustawienie widocznosci na tak
        frame.pack();
        frame.setVisible(true);
    }

    static class MyPanel2 extends JPanel
            // klasa rozszerza JPanel więc mozę być użyty jako takowy
    {
        //nieobowiązkowe nadpisanie paintComoponentu
        //paintComponetnt uruchamia się ałtomatyczne po dodaniu panelu i rysuje po nim, paint component utuchamia się również za każdym razem kiedy elementy obrazku mają ulec zmianie

        private JSlider js1;

        MyPanel2(JSlider js1)
        {
            this.js1=js1;
        }

        //paint Component wywoła się kiedy dowalna zmienna w g ulegnie zmiannie lub gdy zostanie wywołany
        @Override
        public void paintComponent(Graphics g)
        //g jest lokalizacją w tym przypadku panelem
        {
            //odwołanie się do klasy nadrzędnej (obowiązkowwa głupota)
            super.paintComponent(g);

            //ustawienie bacgroundu i koloru do rysowania
            this.setBackground(Color.WHITE);
            g.setColor(Color.BLUE);

            // tak można pobrać wielkośc panelu od wewnątrz
            int height = this.getHeight();
            int width = this.getWidth();
            int prop = js1.getValue();


            // tak wypełnia się owale w zależności od zmiennych opartych na wartościach zmiennych
            g.fillRect((width/2-(prop*height/200)), (height/2-(prop*width/200)), height*prop/100, height*prop/100);

        }
    }
}
