package WSZYSTKO.CWICZENIA.CWICZENIA5;

import java.util.Collection;

public class Person implements Comparable<Person> /*rozszerza comparable*/
{
    private String name;
    private int birthYear;

    public Person(String name, int birthYear){
        this.name = name;
        this.birthYear = birthYear;
    }

    //weryfikacja czy osoba jest w liście
    public static boolean isInColl(Collection<Person> coll, String name, int year) {
        return coll.contains(new Person(name, year));
    }

    // dla obiektów które można umieszczać w listach należy nadpisać metode equals
    @Override
    public boolean equals(Object o)
    {
        Person p = (Person) o;
        //sprawdza czy wszystkie dane się zgadzają
        return this.name.equals(p.name) && this.birthYear == p.birthYear;
    }

    // dla HashSet zwraca unikalne wartośći w tum przypadku hashcode striga z dodabnym wiekiem(dla dwóch obiektów z których equals by zwrócił true haskcode ma być tai sam)
    //hashcode pozwala identyfikować zmienne
    @Override
    public int hashCode(){
        return name.hashCode() + birthYear;
    }

    // dla TreeSet, bez tego nie zadziałą, nadpisujemy compareTo() do porównywanie obiektów
    @Override
    public int compareTo(Person p1)
    {
        //zwraca porównanie najpierw po iminiu a potem po dacie urodzenia
        if(this.name.compareTo(p1.name) == 0)
            return this.birthYear - p1.birthYear;
        return this.name.compareTo(p1.name);
    }

    @Override
    public String toString(){
        return name + "(" + birthYear + ")";
    }
}
