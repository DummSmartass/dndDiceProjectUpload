package WSZYSTKO.CWICZENIA.CWICZENIA5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import static java.lang.System.out;

public class z5 {
    public static void main(String[] args) {
        //Zadanie 1
        List<Person> list = Arrays.asList(
                new Person("Alice", 2000),
                new Person("Brenda", 2001),
                new Person("Cecilia", 2002)
        );

        //sprawdznie czy obiekty znajdują sie w liście
        out.println(Person.isInColl(list, "Brenda", 2001));
        out.println(Person.isInColl(list, "Debby", 2001));

        //treeSet jest szybki i wydajny, dobry do składowania dużych ilości informacji, jest on posortowany
        Set<Person> tSet = new TreeSet<>(list);
        //Stworznie TreeSetu z listy

        out.println(Person.isInColl(tSet, "Brenda", 2001));
        out.println(Person.isInColl(tSet, "Debby", 2001));

        //Hashe ste przechowuje zmienne bez duplikatów o dowlonych unikalnych kluczach(jednakowego typu)
        Set<Person> hSet = new HashSet<>(list);
        out.println(Person.isInColl(hSet, "Brenda", 2001));
        out.println(Person.isInColl(hSet, "Debby", 2001));

        //Zadanie 2
        String[] arr =
        {
                "salon A", "Mercedes", "130000",
                "salon B", "Mercedes", "120000",
                "salon C", "Ford", "110000",
                "salon B", "Opel", "90000",
                "salon C", "Honda", "95000",
                "salon A", "Ford", "105000",
                "salon A", "Renault", "75000"
        };

        //mapy służa do przechowywania obiektów w oparciu o unikalny klucz
        // ta mapa jako lucza używa Stringa i przechowuje obiekty typu list samochódów
        //tak się tworzy hashmape
        Map<String, List<Car>> map = new HashMap<>();

        //dla każdych trzech elementów listy
        for(int i = 0; i < arr.length; i += 3)
        {
            // zmienna tymcasowa typu Car jest tworzona na podstawie 2 i 3 elementu z trzyelementowego rzutu(1,2)
            Car c = new Car(arr[i+1], Integer.parseInt(arr[i+2]) /*parse int zaminenia na inty*/ );

            //jeżeli dany obiekt nie istnieje
            if(!map.containsKey(arr[i]))
            {
                //dodanie nowego elementu do mapy
                map.put(arr[i], new ArrayList<>());
            }

            //uzyskanie elemntu mapy i dodanie do niego samochodu
            map.get(arr[i]).add(c);
        }
        out.println(map);

        String k = "";
        Car najtanszy = null;
        int lowest = 100000000;
        for(String key : map.keySet() /*map.keySet zwraca set unikalnych kluczy uzyskany z mapy*/ )

        {
            //skopiownaie listy pod podanym kluczem do zmiennej pomocniczej
            List<Car> l = map.get(key);

            //iterowanie po wszystkich samochodach w lisćie
            for(Car c : l)
            {
                //znaleźienie najtańszego samochodu
                if(c.getPrice() < lowest)
                {
                    //apisanie nowje najnirzszej ceny
                    //zapamiętabie klucza(salonu)
                    //zapamiętanies samochodu
                    lowest = c.getPrice();
                    k = key;
                    najtanszy = c;
                }
            }
        }
        out.println(najtanszy.getBrand() + " in " + k + " for " + najtanszy.getPrice());


        //Zadanie 3

        //mapa z kluczem stringowym i Listą elementow Purchase
        Map<String, List<Purchase>> purchaseMap = new HashMap<>();
        try
        {
            // otwrcie pliku
            FileInputStream fin = new FileInputStream("src/WSZYSTKO/CWICZENIA/CWICZENIA5/shopping");

            String str;

            int ch;

            String words = "";

            //dolater
            while ( (ch=fin.read())!= -1)
            {
                //out.print((char)ch);
                if (ch!='\n')
                {
                    words=words+(char)ch;
                }
                else
                {
                    String[] zakupy = words.split("[ \r]");
                    words="";

                    //jeżeli dany obiekt nie istnieje
                    if(!purchaseMap.containsKey(zakupy[0]))
                    {
                        //dodanie nowego elementu do mapy
                        purchaseMap.put(zakupy[0], new ArrayList<>());
                    }

                    //uzyskanie elemntu mapy i dodanie do niego samochodu
                    Purchase c = new Purchase(zakupy[1],Integer.parseInt(zakupy[2]));
                    purchaseMap.get(zakupy[0]).add(c);
                }
            }
            fin.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }

        //tak iteruje się po haspaie
        for
        (
                /*List<Purchase> purchases : purchaseMap.values())*/
                String key :purchaseMap.keySet()
        )
        {
            //out.println(purchases);

            List<String> uniqies = new ArrayList<>();
            int total=0;

            for (Purchase p : purchaseMap.get(key))
            {
                //lista zaiwrać będzie wszytskie unikalne przedmioty
                if(!uniqies.contains(p.name))
                    uniqies.add(p.name);

                //tu obliczona jest suma wartości wszystkicj elementów
                total += p.price;
            }

            out.println(key+" "+purchaseMap.get(key).size()+" "+uniqies.size()+" "+total);

        }

    }
}
