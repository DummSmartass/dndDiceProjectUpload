package WSZYSTKO.CWICZENIA.CWICZENIA14;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.NumberBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception
    {
        GridPane root = new GridPane();

        //Integer bindings
        //Integer properties zachowują się jak integery, ale zmiana ich wartości powoduje zmiane wartości elementów na które się składają
        IntegerProperty iA = new SimpleIntegerProperty(0);
        IntegerProperty iB = new SimpleIntegerProperty(0);

        //NumberBinding trzyma wartości liczbowe które mogą się zmeniaćdynamicznie ze względu na wartości ich składowych
        //Bindings.add(iA, iB); dodaje wartości wszystkich swoich elementów
        NumberBinding tot = Bindings.add(iA, iB);

        // numberBididngi mogą być elementami innych numberBiningów(patrz tot)
        //Bindings.divide(tot, 2.); zwraca wynik z dzielenia dwóch wartości
        NumberBinding avg = Bindings.divide(tot, 2.);

        //Góźiki
        Button pA = new Button("+");
        Button mA = new Button("-");
        Button pB = new Button("+");
        Button mB = new Button("-");
        Button pAll = new Button("+1 all");
        Button mAll = new Button("-1 all");

        //Lnaklejki
        Label a = new Label("Alice");
        //można rotować labele(rotacja następuje w stopniach)
        a.setRotate(90);
        Label b = new Label("Beatrice");
        b.setRotate(90);
        Label total = new Label("Tot-> ");
        total.setRotate(90);
        Label nTot = new Label("0");
        //można uzależnić dowolną wartość w programie za pomocą .bind(Property lub Binding)
        //tot.asString() interpretuje element jako string
        nTot.textProperty().bind(tot.asString());
        Label average = new Label("Ave-> ");
        average.setRotate(90);
        Label nAvg = new Label("0");
        nAvg.textProperty().bind(avg.asString());
        Label a2 = new Label("Alice: ");
        Label aTotal = new Label("0");
        aTotal.textProperty().bind(iA.asString());
        Label b2 = new Label("Beatrice: ");
        Label bTotal = new Label("0");
        bTotal.textProperty().bind(iB.asString());

        // element reaguje konkretnie na naciśnięcie myszką
        pA.setOnMousePressed
        (
                //tu może być cokolwiek napoisane
                dupa ->
                {
                    //można kontrolować wartość zmiennych z typów properties za pomocą set i get
                    iA.set(iA.get()+1);
                }
        );

        mA.setOnMousePressed
        (
                event ->
                {
                    iA.set(iA.get()-1);
                }
        );

        pB.setOnMousePressed
        (
                event ->
                {
                    iB.set(iB.get()+1);
                }
        );

        mB.setOnMousePressed
        (
                event ->
                {
                    iB.set(iB.get()-1);
                }
        );

        pAll.setOnMousePressed
        (
                event ->
                {
                    iA.set(iA.get()+1);
                    iB.set(iB.get()+1);
                }
        );

        mAll.setOnMousePressed
        (
                event ->
                {
                    iA.set(iA.get()-1);
                    iB.set(iB.get()-1);
                }
        );

        //Alignment
        //do roota można dodawać elementy razem z ich lokalizacjami w jednostach
        root.add(pA, 0, 0);
        root.add(pB, 1, 0);
        root.add(pAll, 2, 0, 3, 1);
        root.add(a, 0, 1, 1, 2);
        root.add(b, 1, 1, 1, 2);
        root.add(total, 2, 1);
        root.add(nTot, 2, 2);
        root.add(average, 4, 1);
        root.add(nAvg, 4, 2);
        root.add(mA, 0, 3);
        root.add(mB, 1, 3);
        root.add(mAll, 2, 3, 3, 1);
        root.add(a2, 0, 4);
        root.add(aTotal, 1, 4);
        root.add(b2, 2, 4);
        root.add(bTotal, 3, 4);

        // tu ustawia się dostępną przestrzeń pomiędczy elementami
        root.setHgap(20);
        root.setVgap(20);

        // tu ustawia się odległość od ścian aplikacji we wszystkich kierunkach
        root.setPadding(new Insets(10, 10, 10, 10));


        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
