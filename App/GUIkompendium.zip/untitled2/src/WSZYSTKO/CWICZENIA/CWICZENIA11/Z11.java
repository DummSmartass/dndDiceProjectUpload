package WSZYSTKO.CWICZENIA.CWICZENIA11;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Z11
{
    //można najwyraźniej zastąpić invoke later funkcją
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> okno2());
    }

    static public void okno1()
    {
        JFrame frame = new JFrame("Window");

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JTextArea textArea = new JTextArea(20, 30);
        //textArea.setLineWrap(true);

        JButton b1 = new JButton("Close");
        JButton b2 = new JButton("Choose file");

        //pusty label na środku
        JLabel label = new JLabel("", SwingConstants.CENTER);

        //Jscrollpane pozwala przewijać po obiekytah za dużych aby były możliwe do zołaczenia w całości na raz
        JScrollPane scrollPane = new JScrollPane
        (
                //argumentami są obiekt na którym mają by założone sówaki
                // jaki i sówaki jakie chcesz dodać
                textArea,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS
        );

        //action listener do zakończenia programu(lambda)
        b1.addActionListener(e -> System.exit(0));

        //action listener do zakończenia programu nowy obiek Action Listener z nadpisana ActionPerformed
        b2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //obiek typu fileChooser przyjmuje obiekt typu file i wyświetla ten plik w dostępie przeglądarki plków
                JFileChooser chooser = new JFileChooser(new File(System.getProperty("user.home")));

                //obiekt typu FileNameExtensionFilter pozwala filtrować wyśiwietlone dane według rozszerzeń(można wielu)
                //pozwal on też ustawiać nazwe tego trybu wyszukiwania
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Text file", "txt");

                //tak ustawia sięfiltr do przeglądałki plików
                chooser.setFileFilter(filter);

                //.showOpenDialog(chooser pokazuje czy dany plik może być uzyskany przez program porzez wyświetlenie jednej z poniższych opcji
                //CANCEL_OPTION
                //APPROVE_OPTION tylko APPROVE_OPTION pozwala dostać się do pliku
                //ERROR_OPTION
                int result = chooser.showOpenDialog(chooser);

                if(result == JFileChooser.APPROVE_OPTION)
                {
                    //pozwala pobrać wybrany plik i mieć do niego dostęp w programie
                    File res = chooser.getSelectedFile();

                    try
                    {
                        //res.toPath() podaje ścieżke do pliku
                        //Files.readAllBytes(ścieżka do pliku) pozwala odczyać wszystkie bajty zawarte w  pliku(i umożliwia umieszczenie ich w arrayu)
                        byte[] data = Files.readAllBytes(res.toPath());

                        // String może w kostruktorze uzyskać tablice cyfr i system w jakim ma je czytać aby był w stanie je zinterpretować
                        String text = new String(data, StandardCharsets.UTF_8);

                        //ustawienie w textarei pobranego textu
                        textArea.setText(text);

                        //textArea.setCaretPosition ustawia pozycje kursora w okręlonym miejscu textArei
                        //textArea.getDocument().getLength() pobieradokument i wyciąga z niego długość
                        //cała lińja ustawia pozycje kursora na koniec podanego pliku
                        textArea.setCaretPosition(textArea.getDocument().getLength());

                        //ustawienie textu
                        label.setText(res.getName());
                    }
                    catch (IOException ioException)
                    {
                        ioException.printStackTrace();
                    }
                }
            }
        });

        JPanel jpanel = new JPanel();
        jpanel.add(b1);
        jpanel.add(b2);

        frame.add(label, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(jpanel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }



    static public void okno2()
    {

        JFrame frame = new JFrame("Window");
//        frame.setDefaultCloseOperation();

        JTextArea textArea1 = new JTextArea(20, 30);
        JTextArea textArea2 = new JTextArea(20, 30);

        // stworzenie i uruchomienie Runnerów
        Runner runner1 = new Runner(textArea1);
        Runner runner2 = new Runner(textArea2);

        JScrollPane scrollPane1 = new JScrollPane(textArea1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        JScrollPane scrollPane2 = new JScrollPane(textArea2, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);


        JButton jb1 = new JButton("GO");
        JButton jb2 = new JButton("GO");

        //dodawanie listerów
        jb1.addActionListener
        (
            e->
            {
                //synchronized dla danego threda(lub obiekty klasy rozszerzającej threda pozwala je wybudzić z zewnątrz)
                synchronized (runner1) {runner1.notify();}
                runner1.swap();

                if(runner1.go)
                    jb1.setText("STOP");
                else
                    jb1.setText("GO");
            }
        );
        jb2.addActionListener
        (
            e->
            {
                synchronized (runner2) {runner2.notify();}
                runner2.swap();

                if(runner2.go)
                    jb2.setText("STOP");
                else
                    jb2.setText("GO");
            }
        );


        JPanel panel1 = new JPanel(new BorderLayout());
        JPanel panel2 = new JPanel(new BorderLayout());

        panel1.add(scrollPane1, BorderLayout.CENTER);
        panel1.add(jb1, BorderLayout.SOUTH);
        panel2.add(scrollPane2, BorderLayout.CENTER);
        panel2.add(jb2, BorderLayout.SOUTH);

        frame.add(panel1, BorderLayout.WEST);
        frame.add(panel2, BorderLayout.EAST);

        frame.pack();
        frame.setVisible(true);
    }
}
