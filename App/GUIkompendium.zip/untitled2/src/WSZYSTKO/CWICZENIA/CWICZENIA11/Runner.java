package WSZYSTKO.CWICZENIA.CWICZENIA11;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public
class Runner extends Thread
// rorszerza thread(czyli jakby był threadem)
{

    //można przekazać i zmieniać textaree
    private JTextArea jtxtA;
    // zmienna pomicnicza
    public boolean go;

    public Runner(JTextArea txtA)
    {
        this.jtxtA=txtA;
        this.go=false;

        start();
        // można wystartować thread w konstruktorze
    }

    public void swap()
    {
        go=!go;
    }

    @Override
    public void run()
    {
        // nieksończona pętla
        while (true)
        {
            // jeżeli go jest false
            if(!go)
                // po zsynchronizowaniu threda można go zatrzymać lub uruchomić(wait notify)
                synchronized (this)
                {
                    try
                    {
                        //wait zatrzymuje wykonwanie threda aż thred nie zostanie przebudzony
                        wait();
                    }
                    catch (InterruptedException e)
                    {
                        throw new RuntimeException(e);
                    }
                }
            try
            {
                //randomowy czas sleepu
                sleep((int)(Math.random()*1000+500));
            }
            catch (InterruptedException e)
            {
                throw new RuntimeException(e);
            }

            // zmienna przechowikąca date i jak pobrać obecną date
            LocalDate date = LocalDate.now();
            // zmienna przechowikąca czas i jak pobrać obecny czas
            LocalTime time = LocalTime.now();

            //zmienna przejściowa sprawdzająca czas w zależności od lokacji na świecie
            ZonedDateTime zonedDateTime = ZonedDateTime.of(date,time, ZoneId.of("Poland"));

            // dodadanie pełnego formatu daty do textArei
            jtxtA.append(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).format(zonedDateTime)+"\n");
        }
    }
}

