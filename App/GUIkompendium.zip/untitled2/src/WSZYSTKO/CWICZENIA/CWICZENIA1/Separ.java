package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class Separ implements TwoStringsOper {

    String sep;

    public Separ(String sep){
        this.sep = sep;
    }

    @Override
    public String apply(String a, String b){
        return a + sep + b;
    }
}
