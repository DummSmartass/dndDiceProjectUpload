package WSZYSTKO.CWICZENIA.CWICZENIA1;

interface Reversible {
    Reversible reverse();
}
