package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class ReversibleDouble implements Reversible {
    private double number;

    public ReversibleDouble(double number){
        this.number = number;
    }

    public double getNumber(){
        return number;
    }

    @Override
    public String toString(){
        return number+"";
    }

    //funkcja nie zwraca obiektu tej klasy tylko generalny obiekt riozszerzający podany interfejs
    @Override
    public Reversible reverse(){
        this.number = 1/number;
        return this;
    }
}
