package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class ConcatRev implements TwoStringsOper {
    @Override
    public String apply(String a, String b){
        return b + a;
    }
}
