package WSZYSTKO.CWICZENIA.CWICZENIA1;

abstract class Singer
{
    private String name;
    static int number;

    public Singer(String name){
        this.name = name;

    }

    abstract String sing();

    // wewnątrz klasy abstrakcyjnej następuje odwołanie do funkcji abstrakcyjnej mimo, że jeszcze ona nie iostnije
    @Override
    public String toString(){
        return "(" + number + ") " + name + ": " + sing();
    }

    static Singer loudest(Singer[] singers){
        Singer res = singers[0];
        int max = 0;

        for(Singer s : singers){
            int counter = 0;
            String text = s.sing();

            //sprawdza ile jkest wielkich liter w tekście
            for(int i = 0; i < text.length(); i++){
                int ch = text.charAt(i);

                // wyjrywa czy litera jest wielka
                if(ch >= 'A' && ch <= 'Z')
                    counter++;
            }

            //porównuje ilość wielkich liter z orginałem
            if(counter > max) {
                max = counter;
                res = s;
            }
        }
        return res;
    }
}
