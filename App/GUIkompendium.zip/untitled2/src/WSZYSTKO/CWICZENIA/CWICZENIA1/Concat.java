package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class Concat implements TwoStringsOper
{
    // ta klasa impleentuje TwoStringsOper i nie jest abstrakcyjna więc musi zaimlementowaćwszystkie metody danej klasy
    @Override
    public String apply(String a, String b){
        return a + b;
    }
}
