package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class Initials implements TwoStringsOper {
    @Override
    public String apply(String a, String b){
        return "" + a.charAt(0) + b.charAt(0);
    }
}
