package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class z01 {
    public static void main(String[] args) {
        //Zadanie 1

        //tablica przechowuje obioekty wszystkich klas implementujących interfejs TwoStringsOper mimo, że wszystkie obiekty należą do różnych klas
        TwoStringsOper[] a =
        {
            new Concat(),
            new ConcatRev(),
            new Initials(),
            new Separ(" loves ")
        };

        for(TwoStringsOper op : a)
        {
            // dla każdego obiektu w tej liście można wywołać danąfunkcje bo kazdy z nich rozszerza
            System.out.println(op.apply("Mary", "John"));
        }
        System.out.println();

        //Zadanie 2

        //utworzenie obiektu klasy abstrakcyjnej
        Singer s1 = new Singer("Martin"){
            //tak inicjuje się metode do klasy abstrakcyjnej
            String sing(){
                return "Java IS the Best"; //4
            }
        };

        Singer s2 = new Singer("Joplin")
        {
            String sing(){
                return "CCCaa"; //3
            }
        };

        Singer s3 = new Singer("Houston"){
            String sing(){
                return "aaan M"; //1
            }
        };

        Singer[] sng = {s1, s2, s3};

        // trzeba pamiętać, że tak można zrobić, bardzo wygodne
        for(Singer s : sng) System.out.println(s);

        System.out.println("\n" + Singer.loudest(sng));
        System.out.println();

        //Zadanie 3
        Reversible[] revers = new Reversible[] {
                new ReversibleString("Cat"),
                new ReversibleDouble(2),
                new ReversibleDouble(3),
                new ReversibleString("Dog"),
                new ReversibleString("Alice in Wonderland"),
                new ReversibleDouble(10)
        };

        System.out.println("Original:");
        for(Reversible r : revers) System.out.println(r);

        for(Reversible r : revers) {r.reverse(); }

        System.out.println("Reversed:");
        for(Reversible r : revers) System.out.println(r);

        System.out.println("Reversed again and modified:");
        for(Reversible r : revers){
            r.reverse();

            // instanceof zwraca logiczną wartość zdania czy zmienna należy do danej (klasy lub rozszerza dany interfejs)
            if(r instanceof ReversibleDouble)
                System.out.println(((ReversibleDouble) r).getNumber() + 10);
            else
                System.out.println("Text: " + r);
        }
    }
}
