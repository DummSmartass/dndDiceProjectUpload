package WSZYSTKO.CWICZENIA.CWICZENIA1;

public class ReversibleString implements Reversible {

    private String text;

    public ReversibleString(String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return text;
    }

    @Override
    public Reversible reverse(){
        StringBuilder res = new StringBuilder();

        for(int i = text.length()-1; i >= 0; i--){
            res.append(text.charAt(i));
        }

        this.text = res+"";
        return this;
    }
}
