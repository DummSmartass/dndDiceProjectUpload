package WSZYSTKO.CWICZENIA.CWICZENIA1;

interface TwoStringsOper {
    abstract String apply(String a, String b);
}
