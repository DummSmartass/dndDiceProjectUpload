package WSZYSTKO.CWICZENIA.CWICZENIA3;

import java.util.Comparator;

public class MyColorCompar implements Comparator<MyColor>
//implementuje możliwość porównywania obiektów danego typui(w tym przypasku MyColor)
{

    private int color;

    //przyjęcie oboektu kolor
    public MyColorCompar(int color){
        this.color = color;
    }

    @Override
    public int compare(MyColor o1, MyColor o2) {
        return switch (color)
        { // sortuje po czerownym,zielonym,niebieskim w zależności od dostarczonej wartości int
            case 0 -> o1.getRed() - o2.getRed();
            case 1 -> o1.getGreen() - o2.getGreen();
            case 2 -> o1.getBlue() - o2.getBlue();
            default -> 0;
        };
    }
}
