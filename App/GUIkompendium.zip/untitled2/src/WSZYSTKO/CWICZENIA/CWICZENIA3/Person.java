package WSZYSTKO.CWICZENIA.CWICZENIA3;

public class Person {
    private String name;
    private int age;

    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString(){
        return name + " " + age;
    }

    //metoda compareTo
    int compareTo(Person p){
        return age - p.getAge();
    }

    //funkcja sortująca bazująca na metodzie comparrTo
    static void sort(Person[] per){
        for(int i = 0; i < per.length-1; i++){
            int min = i;

            for (int j = i+1; j < per.length; j++)
            {
                if (per[j].compareTo(per[min]) < 0 )
                {
                    min = j;
                }
            }

            if (min != i)
            {
                Person temp = per[i];
                per[i] = per[min];
                per[min] = temp;
            }
        }
    }
}

