package WSZYSTKO.CWICZENIA.CWICZENIA3;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class z3 {

    //tak się robi template w javie
    private static <T,R>void transform(T[] in, R[] out,/*zmienna rozszerza interfej Transofrm dla zmiant elementów typu T na R*/ Transform<T, R> trans) {
        for(int i = 0; i < in.length; i++)
        {
            //dla kaźdego elementu tablicy in typu T w tablicy out R jest umieszczana zmienna przetransformowana w odpowiedni sposób
            out[i] = trans.apply(in[i]);
        }
    }

    //zad 1
    public static void main(String[] args)
    {
        List<MyColor> list = Arrays.asList(
                new MyColor(1, 2, 3),
                new MyColor(255, 0, 0),
                new MyColor(55, 55, 100),
                new MyColor(10, 255, 10)
        );
        System.out.println(list);

        // nie można posortować customowo utworzonej klasy jeżeli nie ma ona nadmisanego compareTo
        //Collections.sort(list);

        System.out.println(list);

        //można posortować podająć <typ>liste i obiekt klasy rozszerzający <typ>komparator
        Collections.sort
        (
                list, new MyColorCompar(0)
        );
        System.out.println(list);
        Collections.sort(
                list, new MyColorCompar(1)
        );
        System.out.println(list);
        Collections.sort(
                list, new MyColorCompar(2)
        );
        System.out.println(list);
        System.out.println();


        //zad 2
        Person[] per = {
                new Person("Maria", 30),
                new Person("Agnes", 26),
                new Person("JJ", 69),
                new Person("Jack", 45),
        };

        for(Person p : per){
            System.out.println(p);
        }
        Person.sort(per);
        System.out.println("\nSorted:");
        for(Person p : per){
            System.out.println(p);
        }


        //3

        String[]  sin = {"Alice", "Sue", "Janet", "Bea"};
        System.out.println(Arrays.toString(sin) +'\n');

        Integer[] iout = new Integer[sin.length];
        transform(sin, iout, new StrToInt() /*StrToInt() to transformator zamieniający strigi na inty n nieznanej mi zasadzie*/ );
        System.out.println(Arrays.toString(iout));

        Character[] cout = new Character[sin.length];
        transform(sin, cout, new Transform<String, Character>()
        {
            //za pomocą nowego oboektu klasy anionimowej inicjuje apply
            @Override
            public Character apply(String a)
            {
                // zwraca podniesiony do Wilekiej litery pierwszy char podanego String
                return Character.toUpperCase(a.charAt(0));
            }
        });
        System.out.println(Arrays.toString(cout));

        String[] sout = new String[sin.length];
        transform(sin, sout,(String a)->{return a.toUpperCase();});
        System.out.println(Arrays.toString(sout));
    }
}
