package WSZYSTKO.CWICZENIA.CWICZENIA3;

public class StrToInt implements Transform<String, Integer> {

    public Integer apply(String s){
        return s.length();
    }
}
