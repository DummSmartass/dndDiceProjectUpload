package WSZYSTKO.CWICZENIA.CWICZENIA3;

@FunctionalInterface
public interface Transform<T, R> {
    public R apply(T a);
}
