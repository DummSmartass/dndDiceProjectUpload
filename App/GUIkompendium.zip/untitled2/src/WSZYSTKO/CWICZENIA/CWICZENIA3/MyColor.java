package WSZYSTKO.CWICZENIA.CWICZENIA3;

public class MyColor extends java.awt.Color
// klasa rozszerza awt kolor więc ma dostęp do wszystkich jej metod
{
    public MyColor(int red, int green, int blue){/*super() przesyła zmienne do analogicznego konstruktora w nadrzędnej klasie*/super(red, green, blue);}

    @Override
    public String toString(){
        return "(" + getRed() + ", " + getGreen() + ", " + getBlue() + ")";
    }
}
