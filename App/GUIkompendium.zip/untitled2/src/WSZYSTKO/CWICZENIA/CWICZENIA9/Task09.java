package WSZYSTKO.CWICZENIA.CWICZENIA9;

import javax.swing.*;
import java.awt.*;

public class Task09 {
    public static void main(String[] args) {
        //SwingUtilities.invokeLater(() -> createFrame1());
        //SwingUtilities.invokeLater(() -> createFrame2());
        //SwingUtilities.invokeLater(() -> createFrame3());
        SwingUtilities.invokeLater(() -> createFrame4());
        //SwingUtilities.invokeLater(() -> createFrame5());
        //SwingUtilities.invokeLater(() -> createFrame6());
    }

    public static void createFrame1(){
        JFrame frame1 = new JFrame("Okno 1");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField textField1 = new JTextField("TextField 1");
        JTextField textField2 = new JTextField("TextField 2");
        JTextField textField3 = new JTextField("TextField 3");

        //grid layout ma określoną z góry ilośćkolum i rzędów
        JPanel jPanel1 = new JPanel( new GridLayout(3, 1) );
        //tak siędo niego dodaje elementy
        jPanel1.add(textField1);
        jPanel1.add(textField2);
        jPanel1.add(textField3);

        JTextArea jTextArea1 = new JTextArea("Text Area 1");

        JButton jb1 = new JButton("B01");
        JButton jb2 = new JButton("B02");
        JButton jb3 = new JButton("B03");
        JButton jb4 = new JButton("B04");
        JButton jb5 = new JButton("B05");
        JButton jb6 = new JButton("B06");
        JButton jb7 = new JButton("B07");
        JButton jb8 = new JButton("B08");
        JButton jb9 = new JButton("B09");

        JPanel jPanel2 = new JPanel( new GridLayout(3, 3) );
        jPanel2.add(jb1);
        jPanel2.add(jb2);
        jPanel2.add(jb3);
        jPanel2.add(jb4);
        jPanel2.add(jb5);
        jPanel2.add(jb6);
        jPanel2.add(jb7);
        jPanel2.add(jb8);
        jPanel2.add(jb9);


        JPanel jPanel3 = new JPanel( new GridLayout(1, 2) );
        jPanel3.add(jTextArea1);
        jPanel3.add(jPanel2);

        //border layout działa też na NORTH,SOUT,EAST,WEST
        frame1.add(jPanel1, BorderLayout.NORTH);
        frame1.add(jPanel3);

        frame1.pack();
        frame1.setLocationRelativeTo(null);
        frame1.setVisible(true);
    }

    public static void createFrame2(){
        JFrame frame2 = new JFrame("Okno 2");
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextArea jTextArea1 = new JTextArea("Text Area 1", 5, 15);

        JButton jb1 = new JButton("B01");
        JButton jb2 = new JButton("B02");
        JButton jb3 = new JButton("B03");
        JButton jb4 = new JButton("B04");

        JPanel jPanel1 = new JPanel(new GridLayout(2, 2));
        jPanel1.add(jb1);
        jPanel1.add(jb2);
        jPanel1.add(jb3);
        jPanel1.add(jb4);

        JButton jb5 = new JButton("B05");
        JButton jb6 = new JButton("B06");
        JButton jb7 = new JButton("B07");
        JButton jb8 = new JButton("B08");

        JPanel jPanel2 = new JPanel(new GridLayout(2, 2));
        jPanel2.add(jb5);
        jPanel2.add(jb6);
        jPanel2.add(jb7);
        jPanel2.add(jb8);

        JTextField jTextField1 = new JTextField("Text Field 1");
        JTextField jTextField2 = new JTextField("Text Field 2");
        JTextField jTextField3 = new JTextField("Text Field 3");

        JPanel jPanel3 = new JPanel(new GridLayout(3, 1));
        jPanel3.add(jTextField1);
        jPanel3.add(jTextField2);
        jPanel3.add(jTextField3);

        JPanel jPanel4 = new JPanel(new GridLayout(1, 3));
        jPanel4.add(jPanel1);
        jPanel4.add(jPanel3);
        jPanel4.add(jPanel2);

        frame2.add(jTextArea1, BorderLayout.NORTH);
        frame2.add(jPanel4);

        frame2.pack();
        frame2.setLocationRelativeTo(null);
        frame2.setVisible(true);
    }

    public static void createFrame3(){
        JFrame frame3 = new JFrame("Okno 3");
        frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextField jTextField1 = new JTextField("Text Field 1");
        JTextField jTextField2 = new JTextField("Text Field 2");
        JTextField jTextField3 = new JTextField("Text Field 3");

        JPanel jPanel1 = new JPanel(new GridLayout(3, 1));
        jPanel1.add(jTextField1);
        jPanel1.add(jTextField2);
        jPanel1.add(jTextField3);

        JTextArea jTextArea1 = new JTextArea("Text Area 1", 5, 10);
        JTextArea jTextArea2 = new JTextArea("Text Area 2", 5, 10);

        JPanel jPanel2 = new JPanel(new GridLayout(1, 2));
        jPanel2.add(jTextArea1);
        jPanel2.add(jTextArea2);

        JButton jb1 = new JButton("B01");
        JButton jb2 = new JButton("B02");
        JButton jb3 = new JButton("B03");
        JButton jb4 = new JButton("B04");
        JButton jb5 = new JButton("B05");

        JPanel jPanel3 = new JPanel( new GridLayout(1, 5));
        jPanel3.add(jb1);
        jPanel3.add(jb2);
        jPanel3.add(jb3);
        jPanel3.add(jb4);
        jPanel3.add(jb5);

        frame3.add(jPanel1, BorderLayout.NORTH);
        frame3.add(jPanel2, BorderLayout.CENTER);
        frame3.add(jPanel3, BorderLayout.SOUTH);

        frame3.pack();
        frame3.setLocationRelativeTo(null);
        frame3.setVisible(true);
    }

    public static void createFrame4(){
        JFrame frame4 = new JFrame("Okno 4");
        frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton[] jbts = new JButton[12];
        for(int i = 0; i < 12; i++){
            jbts[i] = new JButton("B" + (i+1));
        }

        JPanel jPanel1 = new JPanel(new GridLayout(3, 4));
        for(int i = 0; i < 12; i++)
            jPanel1.add(jbts[i]);

        JTextArea jTextArea1 = new JTextArea("Text Area 1");
        JTextArea jTextArea2 = new JTextArea("Text Area 2");

        JPanel jPanel2 = new JPanel(new GridLayout(1, 3));
        jPanel2.add(jTextArea1);
        jPanel2.add(jPanel1);
        jPanel2.add(jTextArea2);

        JTextField jTextField = new JTextField("Text Field 1");

        frame4.add(jTextArea1, BorderLayout.WEST);
        frame4.add(jTextArea2, BorderLayout.EAST);
        frame4.add(jPanel1, BorderLayout.CENTER);
        frame4.add(jTextField, BorderLayout.SOUTH);

        frame4.pack();
        frame4.setLocationRelativeTo(null);
        frame4.setVisible(true);
    }

    public static void createFrame5(){
        JFrame frame5 = new JFrame("Okno 5");
        frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton[] jbts = new JButton[13];
        for(int i = 0; i < 13; i++){
            jbts[i] = new JButton("B" + (i+1));
        }

        JPanel jPanel1 = new JPanel(new GridLayout(2, 5));
        for(int i = 0; i < 10; i++)
            jPanel1.add(jbts[i]);

        JPanel jPanel2 = new JPanel(new GridLayout(1, 3));
        jPanel2.add(jbts[10]);
        jPanel2.add(jbts[11]);
        jPanel2.add(jbts[12]);

        JPanel jPanel4 = new JPanel();
        jPanel4.add(jPanel2, BorderLayout.CENTER);

        JTextField jTextField1 = new JTextField("Text field 1");
        JTextField jTextField2 = new JTextField("Text field 2");
        JTextField jTextField3 = new JTextField("Text field 3");

        JPanel jPanel3 = new JPanel(new GridLayout(3, 1));
        jPanel3.add(jTextField1);
        jPanel3.add(jTextField2);
        jPanel3.add(jTextField3);

        frame5.add(jPanel1, BorderLayout.NORTH);
        frame5.add(jPanel3);
        frame5.add(jPanel4, BorderLayout.SOUTH);

        frame5.pack();
        frame5.setLocationRelativeTo(null);
        frame5.setVisible(true);
    }

    public static void createFrame6(){
        JFrame frame6 = new JFrame("Okno 6");
        frame6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton[] jbts = new JButton[8];
        for(int i = 0; i < 8; i++){
            jbts[i] = new JButton("B0" + (i+1));
        }

        JPanel jPanel1 = new JPanel(new GridLayout(1, 4));
        for(int i = 0; i < 4; i++)
            jPanel1.add(jbts[i]);

        JPanel jPanel2 = new JPanel(new GridLayout(1, 4));
        for(int i = 4; i < 8; i++)
            jPanel2.add(jbts[i]);

        JTextArea jTextArea = new JTextArea("Text Area 1");
        JTextField jTextField1 = new JTextField("Text Field 1");
        JTextField jTextField2 = new JTextField("Text Field 2");
        JTextField jTextField3 = new JTextField("Text Field 3");

        JPanel jPanel3 = new JPanel(new GridLayout(3, 1));
        jPanel3.add(jTextField1);
        jPanel3.add(jTextField2);
        jPanel3.add(jTextField3);

        JPanel jPanel4 = new JPanel(new GridLayout(1, 2));
        jPanel4.add(jTextArea);
        jPanel4.add(jPanel3);

        frame6.add(jPanel1, BorderLayout.NORTH);
        frame6.add(jPanel4);
        frame6.add(jPanel2, BorderLayout.SOUTH);

        frame6.pack();
        frame6.setLocationRelativeTo(null);
        frame6.setVisible(true);
    }
}
