package WSZYSTKO.WYKLADY.WYKLAD12.ex01;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Main extends Application
{
    @Override
    public void start(Stage stage) throws Exception
    {

        //Group root = new Group();
        StackPane root = new StackPane();

        Scene scene = new Scene( root, 640, 480);

        Rectangle backGround = new Rectangle();

        //.setFill() pozwala ustawić kolor elementu
        backGround.setFill(Color.DEEPPINK);

        //backGround.setWidth(scene.getWidth());
        //backGround.setHeight(scene.getHeight());

        //backGround.widthProperty() // odwołuje się do wartości szerokości prostokątak
        //.bind(scene.widthProperty()) // powouje wprowadzenie zależności pomiędzy wielkością elementów (w tym przypadku ma to być wielkoś ekranu podzielona przez 2)
        backGround.widthProperty().bind(
            // ze względu, że root jest typu group wypełnia to tylko prawą górnąćwiartkę
            scene.widthProperty().divide(2)
        );
        backGround.heightProperty().bind(
            scene.heightProperty().divide(2)
        );

        root.getChildren().add(backGround);

        stage.setScene(scene);
        stage.show();
    }
}
