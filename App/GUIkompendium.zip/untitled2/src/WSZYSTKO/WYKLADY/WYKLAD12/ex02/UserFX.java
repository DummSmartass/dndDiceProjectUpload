package WSZYSTKO.WYKLADY.WYKLAD12.ex02;

import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class UserFX
{

    private final String USERNAME_PROP_NAME = "username";

    //przekazywalny string tylko do czytania
    private final ReadOnlyStringWrapper userName;

    private final String PASSWORD_PROP_NAME = "password";

    //string property po prostu
    private final StringProperty password;

    public UserFX(){
        userName = new ReadOnlyStringWrapper(
            //this - loakalizacja isrnienia zmiennej,
            //USERNAME_PROP_NAME -
            // "edu" zawartość
            this, USERNAME_PROP_NAME, "edu"
        );

        //analogicznie jest wyżej
        password = new SimpleStringProperty(
            this, PASSWORD_PROP_NAME, "1234qwer"
        );
    }

    public ReadOnlyStringWrapper userNameProperty(){
        return userName;
    }

    public StringProperty passwordProperty(){
        return password;
    }
}