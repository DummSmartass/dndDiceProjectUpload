package WSZYSTKO.WYKLADY.WYKLAD12.ex02;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public
    class Main
    extends Application {

    //przechowuje booleany, ale można względem niego bindować inne zmienne
    public final static BooleanProperty GRANTED_ACCESS = new SimpleBooleanProperty();

    //to
    private final static int MAX_ATTEMPTS = 3;

    //przechowuje inty, ale można względem niego bindować inne zmienne
    private final IntegerProperty ATTEMPTS = new SimpleIntegerProperty();

    @Override
    public void start(Stage stage) throws Exception
    {

        //zmienna typu user
        UserFX user = new UserFX();

        Group root = new Group();

        Scene scene = new Scene( root, 220, 160);

        Rectangle backGround = new Rectangle();
        backGround.setFill(Color.DEEPPINK);

        backGround.widthProperty().bind(
            scene.widthProperty()
        );
        backGround.heightProperty().bind(
            scene.heightProperty()
        );

        //Label to label
        Label userName = new Label();

        //Password field jest jak textfield który nie pokazuje co w niego wpisujesz
        PasswordField passwordField = new PasswordField();

        //wartość zmiennej jest powiązana z wynikiem operacji user.userNameProperty()
        userName.textProperty().bind(
            user.userNameProperty()
        );

        //dodanie listenera do textowej częsi passwordFielda
        passwordField.textProperty().addListener
        (
             // podane zmienne dobVslue - obserwable value, ov -old value, nv - new walue
            (obsVal, ov, nv) -> {
                GRANTED_ACCESS.set
                (
                    // czy value hasła jest równe podanemu tekstowi
                    user.passwordProperty().getValue().equals(nv)
                );
            }
        );

        //on action w passwordField uruchamia się [przy urzyciu enetera
        passwordField.setOnAction
        (

            evt -> {
                if(GRANTED_ACCESS.get())
                    backGround.setFill(Color.GREEN);
                else{
                    ATTEMPTS.set
                    (
                        // attepts to ilość prób
                        ATTEMPTS.add(1).get()
                    );
                    backGround.setFill(Color.BLACK);
                }
            }
        );


        // do zmiennej  intproperty można dodać listener
        //uruchamia się ona za każdym razem kiedy zmienna ulega modyfikacji
        ATTEMPTS.addListener(
/*
            new ChangeListener<Number>() {
                @Override
                public void changed(
                    ObservableValue<? extends Number> observableValue,
                    Number ov,
                    Number nv
                ) {

                }
            }
 */

            ( obs, ov, nv) ->
            {
                //jeżeli nowa zmienna osiągnie wartość max program się kończy
                if (MAX_ATTEMPTS == nv.intValue())
                    Platform.exit();
            }
        );

        // 3 oznacza miejsce przygotowane na trzy komponenty
        VBox fb = new VBox(3, userName, passwordField);

        root.getChildren().addAll( backGround, fb);

        // .initStyle dobiera opcje obsługi okna(Style)
        //StageStyle.TRANSPARENT usówa góżnik do zamukania i cału pas górny
        stage.initStyle(StageStyle.TRANSPARENT);

        //powoduje, że okienko jest zawsze widoczne, puki nie jest zamknięte(nie da się go zasłonić inną aplikacją)
        stage.setAlwaysOnTop(true);

        stage.setScene(scene);
        stage.show();
    }
}
