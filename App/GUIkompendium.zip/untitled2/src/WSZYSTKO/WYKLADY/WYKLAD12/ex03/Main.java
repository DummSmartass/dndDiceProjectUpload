package WSZYSTKO.WYKLADY.WYKLAD12.ex03;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        Rectangle rect = new Rectangle( 50, 60);
        //można ustawić kolor(domyślny jest czarny)
        rect.setFill(Color.DARKORANGE);

        //można ustawićwysokość i szerokośćłuku co przekłada się na jego zaokrąglenie
        rect.setArcHeight(60);
        rect.setArcWidth(60);

        //nowy okrąg i jego promień
        Circle circle = new Circle(50);
        circle.setFill(Color.BISQUE);

        //Elipsa
        Ellipse ellipse = new Ellipse();
        ellipse.setRadiusX(60);
        ellipse.setRadiusY(40);
        ellipse.setFill
        (
            //wartości rgb koloru ip rzezroczystość
            Color.rgb( 255, 255, 0, 0.3)
        );

        //Polygon(ustawia się go na podstawie jego 3 lokalizacji)
        Polygon polygon = new Polygon();
        polygon.getPoints().addAll(
            0.0, 0.0,
            50.0, 30.0,
            10.0, 60.0
        );
        polygon.setFill(
            Color.hsb( 120, 1.0, 1.0, 0.5)
        );

        //===============================

        //łuk
        Arc arc = new Arc();
        //xy
        arc.setRadiusX(60);
        arc.setRadiusY(40);

        //kąt odchylenia
        arc.setStartAngle(30);

        //jaki stopień owala jest w nim zawarty(180 to połowa)
        arc.setLength(180);
        arc.setFill(
            // kolor można ustawiać z pomocą hexadecymala
            Color.web("0x0000FF", 0.3)
        );

        QuadCurve quadCurve = new QuadCurve();
        //wektor początkowy
        quadCurve.setStartX(50);
        quadCurve.setStartY(200);

        //wektor końcowy
        quadCurve.setEndX(275);
        quadCurve.setEndY(200);

        //wektor śrokowy
        quadCurve.setControlX(90);
        quadCurve.setControlY(90);

        //Stop zmienna któr a przechowa kolory i przypisuje im wartośći od 0 do 1 reprezentujące ułamek
        Stop[] stops = new Stop[]
        {
            new Stop( 0, Color.BLACK),
            new Stop( 0.5, Color.YELLOW),
            new Stop( 0.8, Color.AQUAMARINE),
            new Stop( 1, Color.DEEPPINK)
            //liczby reprezentują miejscaa gdzie zaczyna się malować kolejnymi kolorami
        };

        //gradient liniowy przechowdzi między kolorami
        LinearGradient gradient = new LinearGradient
        (
            0, 0, 180, 0, false,
            CycleMethod.NO_CYCLE, stops
            // 0, 0, 180, 0, false,    parametry uruchomienia
            //CycleMethod.NO_CYCLE brak cykli(przechowdzi przez wszytsko raz)
            //stops używa stoops jako źrudła
        );

        //można wypełnić coś gradientem zamiast koloru
        quadCurve.setFill(gradient);

        //Hboc - rozstaw pionowy
        //(20) odstęp 20
        HBox root = new HBox(20);
        // rott jet na środku
        root.setAlignment(Pos.CENTER);

        root.getChildren().addAll(
            rect, circle, ellipse, polygon,
            arc, quadCurve
        );

        Scene scene = new Scene( root, 800, 600);
        stage.setScene(scene);
        stage.show();
    }
}
