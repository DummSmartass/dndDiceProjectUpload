package WSZYSTKO.WYKLADY.WYKLAD2.EX5;


public
interface FIA {

    boolean method(int a, int b);
}
