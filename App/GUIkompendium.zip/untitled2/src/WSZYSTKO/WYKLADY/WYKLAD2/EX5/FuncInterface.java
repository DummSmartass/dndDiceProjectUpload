package WSZYSTKO.WYKLADY.WYKLAD2.EX5;

public
interface FuncInterface {

    void method();
}
