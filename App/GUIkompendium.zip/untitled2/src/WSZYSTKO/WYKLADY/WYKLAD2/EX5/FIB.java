package WSZYSTKO.WYKLADY.WYKLAD2.EX5;

public
interface FIB {

    boolean method(int a, int b);
}