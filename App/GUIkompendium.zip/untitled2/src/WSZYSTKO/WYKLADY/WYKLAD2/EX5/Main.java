package WSZYSTKO.WYKLADY.WYKLAD2.EX5;

import java.sql.SQLOutput;

public
class Main {

    public static void main(String[] args) {
        sMet
        (
                new FuncInterface()
                {
                    @Override
                    public void method()
                    {
                        System.out.println("....");
                    }
                }
        );
        // wywołanie metody sMet z podaniem mnowego obieku interfacu z nadpisanąmetodą

        sMet(

                () -> {
                    System.out.println(",,,,");
                }
        );
        // wywołanie metody sMet z nadpisaną jedyną jej metodąza pomoćąlambdy
        // lambdy można użyć jak dana klasa, interface ma tylko jedną metode, wtedy lambda
        //(zmienne)->{ciało}; pozwala nadpisać te metode



        FIA fia = ( e, f) ->
        {
            System.out.println(e+f);
            return true ;
        };
        // przypisanie obiektowi interfacu lambdy zmienia te lamde na takąjaką tu napiszemy

        if(fia.method( 2, 3))
            System.out.println("1");

        FIB fib = ( g, h) -> {
            return g > h;
        };

        fib = ( g, h) -> g > h;// nadpisanie fib
        // metoda fib zwraca boolena więc za pomocą lamdy można jej przypisać dowolny element kodu zwracający któryego wynikiem jest boolean

        System.out.println(
                fib.method(2, 3)
        );

    }

    public static void sMet(FuncInterface fi)
    // publiczna metoda statyczna zadeklarowana w mainie(public static void main nie jest jedyną metodą tego typu jaka może istnieć)
    {
        fi.method();
        // ta metoda wywołuje obiekt bęący implemntacjainterfacu(skrót myśłowy będący obiektem interfacu)
    }
}

