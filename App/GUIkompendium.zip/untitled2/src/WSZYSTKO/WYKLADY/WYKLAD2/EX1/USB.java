package WSZYSTKO.WYKLADY.WYKLAD2.EX1;

public
interface USB
{
    void send(byte[] data);
    String receive();
    // dwie funkcje w interface
}
