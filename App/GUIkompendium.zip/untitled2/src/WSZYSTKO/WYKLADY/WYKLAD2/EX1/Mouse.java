package WSZYSTKO.WYKLADY.WYKLAD2.EX1;


public
class Mouse
        implements USB {

    @Override
    // ovverride nadpisanie funkcji z interfacu w klasie implementująćej
    public void send(byte[] data)
    {
        System.out.println("Connected");
    }

    @Override
    // ovverride nadpisanie funkcji z interfacu w klasie implementująćej

    public String receive()
    {
        return "mouse";
    }
}
