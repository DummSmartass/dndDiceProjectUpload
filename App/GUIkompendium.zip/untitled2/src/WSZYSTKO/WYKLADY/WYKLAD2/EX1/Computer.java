package WSZYSTKO.WYKLADY.WYKLAD2.EX1;

public
class Computer
{

    public void connect(USB usb)
    // komputer zawiera zmiennaą typu interfacu
    {
        usb.send(new byte[]{1});
        // komputer wywołuje funkcje wysłania do urządzenia
        String data = usb.receive();
        // komputer wywołuje funkcje wysłania i odbioru z urządzenia
        // mimo, że nie jest to tu nadpisane można tego użyć
        System.out.println("Device id: "+data);
    }
}
