package WSZYSTKO.WYKLADY.WYKLAD2.EX1;

public
class Main{

    public static void main(String[] args)
    {
        Computer computer = new Computer();
        // towrzenie lementu klasy komputer
        Mouse mouse = new Mouse();
        // tworzenie lementu klasy myszka

        computer.connect(mouse);
        // wysłanie do komputera myszki i wykorzystanie jeje nadpisanych metod
    }
}