package WSZYSTKO.WYKLADY.WYKLAD2.EX2;

public
interface Vechicle
{

    void startEngine();
    void move();

    default boolean engineCheckTime(int km)
     // default pozwala ustawiać domyślne wykonianie metod w interfacach
    {
        return km >= 10000;
    }
}

