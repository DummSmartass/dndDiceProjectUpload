package WSZYSTKO.WYKLADY.WYKLAD2.EX3;

public
class C
        extends Object
        //
        implements A, B {
        // można iplementowaćwiele interfaco

    @Override
    // nadpisanie funkcji występującekj w obu interfacach
    public void xxx()
    {
        A.super.xxx();
        // .super na interfacie pozwala wyciągnąć w klasie implementującej pierwotną metode z intefacu
        B.super.xxx();
    }

    public static void main(String[] args)
    // main, czylie element odpowiedzialny za wywołanie może znajdować sięw dowolnej klasie, nie koniecznie main
    {
        new C().xxx();
        // utowrzenie obiektu i wywołanie funkcji bez tworzenia przypisania tego obiektu nigdize
    }
}

