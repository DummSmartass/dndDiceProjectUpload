package WSZYSTKO.WYKLADY.WYKLAD2.EX3;

public
interface B {

    default void xxx(){
        System.out.println("B xxx()");
    }
}

