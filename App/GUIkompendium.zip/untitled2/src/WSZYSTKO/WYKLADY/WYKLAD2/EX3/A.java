package WSZYSTKO.WYKLADY.WYKLAD2.EX3;

public
interface A {

    default void xxx(){
        System.out.println("A xxx()");
    }
}
