package WSZYSTKO.WYKLADY.WYKLAD2.EX4;

public
interface Vechicle
{

    void startEngine();
    void move();

    default boolean engineCheckTime(int km)
    {
        return km >= 10000;
    }

    static int getHorsePower(int rpm, int torque)
    {
        return (rpm * torque) / 10000;
    }
    // statyczne funkcje nie bazują na elementach zawartych wewnątrz funkcji powoduje to
    //a) nie trzeba tworzyć obiektu danej klasy(w tym przypadku interfacu którego obiektu i tak nie można stworzyć) aby urzywać tej funkcji
    //b) nie korzysta onna z rzadnych zmiennych z wnętrza klasy w kturej jest zaimplementowana iedy jest zaimplementowana w klasie
}
