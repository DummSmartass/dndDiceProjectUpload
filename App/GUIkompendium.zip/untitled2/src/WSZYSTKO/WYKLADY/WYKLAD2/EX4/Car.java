package WSZYSTKO.WYKLADY.WYKLAD2.EX4;

public
class Car
        implements Vechicle {

    private int distance;

    public Car(){
        this.distance = 0;
    }

    @Override
    public void startEngine() {
        if(engineCheckTime(distance))
            System.out.println("pora sprawdzic silnik");
    }

    @Override
    public void move() {
        this.distance++;
    }
}
