package WSZYSTKO.WYKLADY.WYKLAD4.EX1;

public
class Main {

    public static void main(String[] args)
    {
        System.out.println(Suit.HEARTS);
        //wypisanie danego enuma

        fun(Suit.CLUBES);
        // wykonanie funkcji fun z enuma enumie

        System.out.println(Card.TWO);
        System.out.println(Card.TWO.getValue());
        // owypisuje wartość karty

        fun(Card.ACE, Suit.DIAMONDS);
        // inna klasa fun zadekarowana w tej klasie
    }

    public static void fun(Suit suit){
        System.out.println("Suit: "+suit);
        // enumy mogą mieć obiekty swojego typu a tak się je wypisuje
    }
    public static void fun(Card card, Suit suit)
    {
        System.out.println(card + " of "+suit);
    }
}