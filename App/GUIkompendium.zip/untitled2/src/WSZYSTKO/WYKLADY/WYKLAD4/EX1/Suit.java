package WSZYSTKO.WYKLADY.WYKLAD4.EX1;

public
enum Suit {
    // endum to lista elementów typu enumowego, przydantne do niezmiennych list, chyba bardziej wydajne
    HEARTS, DIAMONDS, SPADES, CLUBES
}

