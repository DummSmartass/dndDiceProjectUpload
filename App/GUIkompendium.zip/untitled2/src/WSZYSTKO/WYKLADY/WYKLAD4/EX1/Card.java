package WSZYSTKO.WYKLADY.WYKLAD4.EX1;

public
enum Card {

    TWO(2), KING(11), ACE(12);
    // enumy mogą miećwartośći tak sięje wstawia

    private int value;
    // enumy mogą mieć zmienne

    private Card(int aValue)
    // jeżeli poszczególene unumy mają przechwytywane wartosći np intu, można w ich kreatorze urzyć tej zmiennej i przypisać jądo zmiennej typu enuma
    {
        this.value = aValue;
    }
    // enumy mogą mieć konstruktory i funkcje ta przypisuje wartośćw zależnośći od podnego inta

    public int getValue(){
        return value;
    }

}

