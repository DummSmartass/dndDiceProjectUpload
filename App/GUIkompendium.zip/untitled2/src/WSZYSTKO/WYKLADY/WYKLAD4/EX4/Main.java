package WSZYSTKO.WYKLADY.WYKLAD4.EX4;

import WSZYSTKO.WYKLADY.WYKLAD4.EX3.Student;

import java.util.ArrayList;
import java.util.List;

public
class Main {

    public static void main(String[] args) {
        Student s1 = new Student( "Sylvia", 36, "s0678");
        Student s2 = new Student( "Philipa", 48, "s0002");
        Student s3 = new Student( "Joe", 18, "s0042");

        List<Student> aList = new ArrayList<>();
        // typ arraylisty, studentó może zawierać w sobie elementy typu student i dodaje je sięza pomocą add
        aList.add(s1);
        aList.add(s2);
        aList.add(s3);

        for(Student student : aList)
        // można iterować po arrayliście
            if(student.getAge() > 20)
                System.out.println(student);
    }
}