package WSZYSTKO.WYKLADY.WYKLAD4.EX5;

public
class MyElement<T> {

    private T value;
    private MyElement<T> next;

    public MyElement(T value){
        this.value = value;
        this.next = null;
    }

    public T getValue() {
        return value;
    }

    public MyElement<T> getNext() {
        return next;
    }

    public void setNext(MyElement<T> next) {
        this.next = next;
    }

    // nic nowego
}
