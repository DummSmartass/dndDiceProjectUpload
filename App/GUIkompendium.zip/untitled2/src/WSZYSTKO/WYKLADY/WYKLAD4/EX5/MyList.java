package WSZYSTKO.WYKLADY.WYKLAD4.EX5;

import java.util.Iterator;

public
class MyList<T>
        implements Iterable<T>
    // iterator to interfejs do iterowania
{

    MyElement<T> head;

    public void add(T value){
        MyElement<T> tmp = new MyElement<>(value);
        tmp.setNext(this.head);
        this.head = tmp;
    }

    public void show(){
        MyElement<T> tmp = head;
        while(tmp != null){
            System.out.println(tmp.getValue());
            tmp = tmp.getNext();
        }
    }

    public MyElement<T> getHead() {
        return head;
    }
    // do tego miejsca nic nowego

    @Override
    public Iterator<T> iterator()
    // nadpisanie funkcji iterantor() z Iteratora
    {
        return new Iterator<T>()
        // stworzenie nowego elementu rozszerzającego iterator
        {

            private MyElement<T> tmp = head;
            // przypisanie do zmiennej tmp głowy funkcji

            @Override
            public boolean hasNext() {
                return tmp != null;
            }
            // nadpisnie metody hasNext z interfajsu Iterator sprawdzającej, czy istnieje kolejny elment

            @Override
            public T next()
            //  metody next z interfejsu iterator która zwraca wartość obcnego elemntu ip rzechodzi do następnego
            {
                T value = tmp.getValue();
                tmp = tmp.getNext();
                return value;
            }
        };
        // i zwrucenie go jako nadpisanie metody iterator z iterator
    }
}
