package WSZYSTKO.WYKLADY.WYKLAD4.EX5;

import WSZYSTKO.WYKLADY.WYKLAD4.EX3.Student;

import java.util.Iterator;

public
class Main {

    public static void main(String[] args) {
        Student s1 = new Student( "Sylvia", 36, "s0678");
        Student s2 = new Student( "Philipa", 48, "s0002");
        Student s3 = new Student( "Joe", 18, "s0042");

        MyList<Student> myList = new MyList<>();
        myList.add(s1);
        myList.add(s2);
        myList.add(s3);

        //myList.show();

        Iterator<Student> iter = myList.iterator();
        // elemnent typu iterator studenta z myList.iterator() (przystosowane dla dowolnego typu danej)

        while(iter.hasNext())//można urzywąć funkcji z iteratora
            System.out.println(iter.next());

        for(Student student : myList)
            System.out.println(student);
    }
}

