package WSZYSTKO.WYKLADY.WYKLAD4.EX3;

public
class Student {

    private String name;
    private int age;
    private String id;

    public Student(String name, int age, String id)
    {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    @Override
    public String toString() {
        return "Student("+name+","+age+", "+id+")";
    }

    public int getAge()
    {
        return age;
    }

    // nic niesamowitego kolejna klasa student
}