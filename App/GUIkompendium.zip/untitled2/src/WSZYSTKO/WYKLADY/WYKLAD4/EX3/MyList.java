package WSZYSTKO.WYKLADY.WYKLAD4.EX3;

public
class MyList<T> {

    MyElement<T> head;

    public void add(T value){
        MyElement<T> tmp = new MyElement<>(value);
        tmp.setNext(this.head);
        this.head = tmp;
    }

    public void show(){
        MyElement<T> tmp = head;
        // tworzenie zmiennej pomocniczej tmp do chodzenia po stosie
        while(tmp != null)
        // dopuki tmp nie jest nullem
        {
            System.out.println(tmp.getValue());
            tmp = tmp.getNext();
            //tmp jest zamineinane na kolejne elementy biorąc kolejne getNexty
        }
    }


    public MyElement<T> getHead()
    {
        return head;
    }
}

