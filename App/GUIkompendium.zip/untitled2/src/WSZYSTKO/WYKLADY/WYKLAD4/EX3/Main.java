package WSZYSTKO.WYKLADY.WYKLAD4.EX3;


public
class Main {

    public static void main(String[] args) {
        Student s1 = new Student( "Sylvia", 36, "s0678");
        Student s2 = new Student( "Philipa", 48, "s0002");
        Student s3 = new Student( "Joe", 18, "s0042");
        // stworzenie obiektów student

        MyList<Student> myList = new MyList<>();
        myList.add(s1);
        myList.add(s2);
        myList.add(s3);
        //dodanie obiektów student do stosu

        myList.show();
        // wypisanie studentó

    }
}
