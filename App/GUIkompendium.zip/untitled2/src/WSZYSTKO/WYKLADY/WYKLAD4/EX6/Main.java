package WSZYSTKO.WYKLADY.WYKLAD4.EX6;

import java.util.stream.Stream;

public
class Main
{

    public static void main(String[] args)
    {
        // istniejązmienne typu Stream
        Stream
                .generate(Math::random)
                .limit(10)
                .forEach(System.out::println);
        // ten stram ma
        //      generować(czyli tworzyć według wzoru elemnty o wartościa Math::Random)
        //      ma ustawiony limit takich elementów na 10
        //      dla każdego tego typu elementu ma go wypisać


        Stream
                .iterate( 1, elem -> elem + 2)
                .limit(10)
                .forEach(System.out::println);
        //      ten stream iteruje dany loop (elem -> elem+2) zaczynająć od podanego pierwszego elementu
        //      ma limit 10, czyli skończy się iterowąć kiedy tyle elementów wyprodukuje
        //      każdy z tycch elementów wypisze

        System.out.println("===================");

        Stream
                .iterate( 1, elem -> elem + 1)
                .takeWhile(e1 -> e1 < 10)
                .dropWhile(e2 -> e2 < 5)
                .forEach(System.out::println);
        //ierate
        // .takeWhile bierze kolejne elementy (nazwa elementu wewnątrz jest nieistotna, chodzi o to: e1(po lewej to nasz element obecny) -> (przekazanie) e1<10 (warunek))
        // .dropWhile kończy dane okrążenie iteracji (podobnie jak coninue; w pętlach) jeżęli spełniony jest warunek(wyżej widać jak robić warunki)
        //forEach(sout)

    }
}
