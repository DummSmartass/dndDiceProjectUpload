package WSZYSTKO.WYKLADY.WYKLAD4.EX2;

public
class Main {

    public enum ClassDay{
        MONDAY, FRIDAY, SATURDAY, SUNDAY
    }
    // enum może być zadeklarowany wewnątrz klasy

    public static void main(String[] args)
    {
        ClassDay[] daysOfClasses = ClassDay.values();
        // można tworzyć arrajhe enumów
            for(ClassDay day : daysOfClasses)
                // i je iterować
                System.out.println
                (
                    day + switch(day){
                        case MONDAY, FRIDAY -> " dzien cwiczen z GUI";
                        case SATURDAY, SUNDAY -> " dzien nauki do zajec z GUI";
                    }
                    // otraz używać na nich switcha
                 );
    }
}

