package WSZYSTKO.WYKLADY.WYKLAD5.EX4;

public
class Main {

    public static void main(String[] args)
    {
        // tworzenie i wywoływanie odzielnych obiektów klasy runner
        // rozszerzającej wątek
        new Runner('a').start();
        new Runner('b').start();
        new Runner('c').start();
    }
}
