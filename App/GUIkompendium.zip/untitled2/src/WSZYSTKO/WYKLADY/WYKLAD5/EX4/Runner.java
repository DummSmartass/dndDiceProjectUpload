package WSZYSTKO.WYKLADY.WYKLAD5.EX4;

public
class Runner extends Thread
// klasa rozszerza wątek znaczy klasa to persaldo wątek
{

    private char ch;

    public Runner(char ch)
    {
        this.ch = ch;
    }

    @Override
    // nadpisanie funkcji run z klasy thread
    public void run()
    {
        for (int i = 0; i < 20; i++)
            System.out.print(ch);
    }
}
