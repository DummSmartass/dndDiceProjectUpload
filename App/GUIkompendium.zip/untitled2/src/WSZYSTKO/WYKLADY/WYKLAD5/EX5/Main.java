package WSZYSTKO.WYKLADY.WYKLAD5.EX5;

import java.awt.*;
import java.util.List;
import java.util.ArrayList;

public
class Main extends Frame
// Main dziedziczy po Frame co zaminia ją na frame
{

    public static void main(String[] args)
    {
        new Main();
    }

    List<Ball> ballList;

    public Main()
    {
        ballList = new ArrayList<>();

        for(int i=0; i<10; i++)
        {
            ballList.add
            (
                    new Ball( 320, 240, 50)
            );
        }

        this.setSize(640, 480);
        this.setVisible(true);

        new Thread
        (
                () ->
                // nadpisanie funkcji run threada za pomocą lambdy
                {
                    int sleepTime = 1000/30;
                    //30 klatek na sekunde

                    while( !Thread.currentThread().isInterrupted())
                    //dopuki thread nie jest zaburzony
                    {
                        repaint();
                        // paint znowu
                        try {
                            Thread.sleep(sleepTime);
                            // nie rób niczego przez określony czas
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
        ).start();
        // wątek jest od razu uruchamiany za pomocą .start,
        // różnica, .start - tworzy nowy thread na którym robi run, .run - wykonuje się na obecnym threadzie
    }

    @Override
    public void paint(Graphics g)
    {
        super.paint(g);
        // super.paint(g) - narysowane ponowne dotychczasowego obrazu

        for(Ball ball : ballList)
            ball.draw(g);
        // dla każdego elementu w balllist wykonaj ball.draw(g)
    }
}
