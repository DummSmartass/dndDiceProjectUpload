package WSZYSTKO.WYKLADY.WYKLAD5.EX5;

import java.awt.*;

public
class Ball
implements Runnable
// implementacja interfejsu Runnable zapewnia dostęp do nadpisania funkcji Run podobnie jak extend Threat
{

    private int x, y, size;
    private int vx, vy;
    private Color color;

    public Ball(int x, int y, int size)
    {
        this.x = x;
        this.y = y;
        this.size = size;

        this.vx = (int)(Math.random()*5);
        this.vy = (int)(Math.random()*5);

        this.color = new Color
        (
                (int)(Math.random()*255),
                (int)(Math.random()*255),
                (int)(Math.random()*255)
        );

        new Thread(this).start();
    }

    @Override
    public void run()
    {
        while(!Thread.currentThread().isInterrupted())
        {
            x += vx;
            y += vy;
            // thread przesówa zmienne
            try
            {
                Thread.sleep(50);
            }
            catch (InterruptedException e)
                    // catch when rThread is interupted
            {
                e.printStackTrace();
            }
        }
    }

    public void draw(Graphics g)
    {
        //draw wypełnia owal na danej lokalizacji
        g.setColor(color);
        g.fillOval( x, y, size, size);
    }
}
