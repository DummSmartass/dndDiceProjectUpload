package WSZYSTKO.WYKLADY.WYKLAD5.EX3;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collector;

public
class MyCollectionTask
{

    List<MyItem> l = new LinkedList<>();

    private Integer x, y;
    // x i y zmienne pomocnicze

    public void accept(Double d)
    {
        x = y;
        y = (int)(d.doubleValue()*99);
        // accept przypisuje do x y i do y przetworzoną wartość podanej zmiennej co powoduje, że do listy zapisze wartość raz na dwa wywołania
        if( x != null)
        {
            l.add(new MyItem( x, y));
            x = null;
            y = null;
        }
    }

    public MyCollectionTask combine(MyCollectionTask other)
    {
        throw new UnsupportedOperationException();
        // wyrzuca błąd niewspieranego typu jak podasz do połączenia elementu tego samego typu
    }

    public List<MyItem> finish(){
        return l;
        //zwraca liste
    }

    public static Collector<Double, ?, List<MyItem>> collector()
    {
        return Collector.of
         // Collector.of zbiera wszystkie dane przerobione przez te funkcje
        (
                MyCollectionTask::new, // tworzenie obiektów
                MyCollectionTask::accept, // akumulator, łączy i przesyła wygenerowane wartości
                MyCollectionTask::combine,// combine nie jest obsługiwana
                MyCollectionTask::finish// finalizator zwraca liste
        );
    }
}
