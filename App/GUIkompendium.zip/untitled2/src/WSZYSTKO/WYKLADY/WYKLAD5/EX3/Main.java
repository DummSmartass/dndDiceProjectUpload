package WSZYSTKO.WYKLADY.WYKLAD5.EX3;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public
class Main {

    public static void main(String[] args) {
        List<MyItem> myItemList = new LinkedList<>();
        for(int i=0; i<10; i++){
            MyItem item = new MyItem(
                    (int)(Math.random()*99), (int)(Math.random()*99)
                    // generator wartości losowych
            );
            myItemList.add(item);
            System.out.println(item);
        }


        List<Integer> intList =
        // listy można wypełniaćz użyciem strumini
        Stream
                .generate(Math::random)
                .limit(10)
                .map( e -> (int)(e.doubleValue()*99))// zamiana e po lewej na wartość (int)(e.doubleValue(co zwraca doublową wartość zmiennej)*99)
                .collect(Collectors.toList()); // .collect(Collector.toList()) zbiera elemnty stramu i zaminia je na liste
        intList
                .stream()
                .forEach(System.out::println);

// ===============================================

        List<MyItem> myItemList2 =
                Stream
                .generate(Math::random)
                .limit(10)
                .collect(MyCollectionTask.collector());// patrz klasa zbiera i przerabia elementy
                // można przekazać własny collect przez MyCollectionTask

        myItemList2
                .stream()
                .forEach(System.out::println);

    }
}

