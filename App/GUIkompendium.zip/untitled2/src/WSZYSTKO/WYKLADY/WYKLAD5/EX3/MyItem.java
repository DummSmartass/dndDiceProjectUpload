package WSZYSTKO.WYKLADY.WYKLAD5.EX3;


public
class MyItem {

    private Integer x, y;

    public MyItem(){
    }

    public MyItem(Integer x, Integer y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "MyItem{ x="+x+", y="+y+"}";
    }
}
// nic nowego