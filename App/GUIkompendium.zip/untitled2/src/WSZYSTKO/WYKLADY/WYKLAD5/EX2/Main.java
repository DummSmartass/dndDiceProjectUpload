package WSZYSTKO.WYKLADY.WYKLAD5.EX2;

import java.util.stream.Stream;

public
class Main
{

    public static void main(String[] args)
    {
        Stream<String> nameStr = Stream.of("John","Mary","Olga","Anna","Alice");
        // stream of tworzy obiekt typu Stream zawierający podane Argumenty

        nameStr
                .filter(e->e.startsWith("A"))// przepuszcza danlej elementy które zaczynają się od "A"
                // . filter jest jak odwrócone drop While
                .map(String::toUpperCase)// .map zmienia wartośćdanego elementu
                // toUpperCase zaminia każdy element na taki z wielkiej litery
                .sorted()// sortuje elemnty
                .forEach(System.out::println);
        // raz zamknięty stream już nie może być operowany


    }
}

