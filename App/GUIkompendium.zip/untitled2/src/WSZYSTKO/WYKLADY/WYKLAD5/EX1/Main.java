package WSZYSTKO.WYKLADY.WYKLAD5.EX1;

import java.util.Arrays;
import java.util.List;

public
class Main {

    public static void main(String[] args)
    {
        List<String> strings = Arrays.asList("a1", "a2", "b3", "b4", "c5", "c6");
        // Arrays.asList bierzee podane argumenty i przerabia je na liste


        strings
                .stream() // .stream tworzy stream zawierający elementy z podanej listy
                .map(str -> str.substring(1))// zamienia element na substring na pozycji 1(czyli drugiej)
                .mapToInt(Integer::parseInt)// mapToInt zaminia na integery  używająć ParseInt(funkcji na zamineianie stringów na inty)
                .forEach(System.out::println);


    }
}
