package WSZYSTKO.WYKLADY.WYKLAD1;
// analogicznie do Square
import java.awt.*;

public
class Rectangle
        extends Figure
{

    protected double sideA, sideB;

    public Rectangle(double sideA, double sideB)
    {
        this.sideA = sideA;
        this.sideB = sideB;
    }

    @Override
    public double getFiled()
    {
        return sideA*sideB;
    }

    @Override
    public void draw(Graphics g)
    {
        g.setColor(Color.RED);
        g.drawRect( 100, 100, (int)sideA, (int)sideB);
    }
}

