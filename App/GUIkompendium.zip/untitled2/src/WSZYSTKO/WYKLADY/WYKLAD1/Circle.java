package WSZYSTKO.WYKLADY.WYKLAD1;
// analogicznie do Square
import java.awt.*;

public
class Circle
        extends Figure
{

    private double radius;

    public Circle(double radius)
    {
        this.radius = radius;
    }

    @Override
    public double getFiled()
    {
        return Math.PI*(radius*radius);
    }

    @Override
    public void draw(Graphics g)
    {
        g.setColor(Color.BLUE);
        // .setColor - ustawia kolor elementu
        g.fillOval( 400, 100, (int)radius*2, (int)radius*2);
        //.drawOval to dostępna dla elementów graficznych funkcja do rysowania wypełnionego Owalu, na danej lokalizacji i o danych wymiarach
    }
}
