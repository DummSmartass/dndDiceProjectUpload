package WSZYSTKO.WYKLADY.WYKLAD1;

public abstract class Figure implements Drawable
// abstract class, nie może być obiektu tej klasy, klasa może mieć zmienne i metody w tym metody abstrakcyjne
// implements oznacza, że w tej klasie zaimplementowane są funkcje z interfacu
{
    public abstract double getFiled();
    // klasa abstrakcyjna jest implementowana w podrzędnych klasach
}
