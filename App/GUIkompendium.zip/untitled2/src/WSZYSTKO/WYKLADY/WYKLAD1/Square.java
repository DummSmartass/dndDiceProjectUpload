package WSZYSTKO.WYKLADY.WYKLAD1;

import java.awt.*;

public class Square extends Figure
// extends znaczy, żę ta klasa dziedziczy po podanej klasie,
// znaczy to, że ta klasu ma dostęp do zmiennych i metod public i protected z klasy nadrzędnej,
// jak i musi implementować metody abstrakcyjne tej klasy jak i metody interfacu zaimplementowanego w klasie nadrzędnej
{
    private int side;

    public Square(int side)
    {
        this.side = side;
    }

    @Override
    // @Override oznacza nadpisanie metody o danej nazwie i ilośći argumentów, w tym przypadku metody abstrakcyjnej z funkcji nadrzędnej
    public double getFiled()
    {
        return side*side;
    }

    @Override
    // tu implementowana jest funkcja draw z interfacu Drawable
    public void draw(Graphics g)
    {
        g.drawRect( 100, 100, side, side);
        // g to element graficzny jak kartka papieru
        //.drawRect to dostępna dla elementów graficznych funkcja do rysowania pustego prostokąta, na danej lokalizacji i o danych wymiarach
    }
}

