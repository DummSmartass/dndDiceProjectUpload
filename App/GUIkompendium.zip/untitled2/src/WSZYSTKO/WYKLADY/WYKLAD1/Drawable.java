package WSZYSTKO.WYKLADY.WYKLAD1;

import java.awt.*;
// jawa.awt do interfejsów graficznych

public interface Drawable
// interface - zestaw metod
{
    void draw(Graphics g);
}
