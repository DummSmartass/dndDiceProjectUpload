package WSZYSTKO.WYKLADY.WYKLAD1;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public
class Main extends Frame
// main rozszerza frame, co powoduje, że main staje się klasą bęąćą okienkiem
{
    private Drawable arr[];
    // klasa Main może posiadać włassne zmienne
    // interface, może  mieć własny array

    public static void main(String[] args)
    {
        new Main();
        // klasa main może być wywołana przez swuj komponent
    }

    public Main()
    {
        arr = new Drawable[2];

        arr[0] = new Rectangle( 100, 100);
        arr[1] = new Circle( 100);
        // array typu Interface można wypełniać obiektami funkcji go implementujących pośrednio lub bezpośrednio w tym przypadku rectangle i Circle

        this.addWindowListener
        // do funkcji main można odwołać się przez this
        // od funkcji można dodaćWindowsListenera
        // window listener pozwala towrzyć okienaka
        (
                new WindowAdapter()
                {
                    @Override
                    public void windowClosing(WindowEvent e)
                    {
                        System.exit(0);
                    }
                }
        );

        this.setSize( 640, 480);
        // ustawia wielkość Maina która dziedziczy po frame więć "jest frmame(okienkiem)"
        this.setVisible(true);
        // powoduje,że okienko jest widoczne
    }

    public void paint(Graphics g)
    // deklaracja funkcji pain
    {
        for(Drawable drawble : arr)
            drawble.draw(g);
        // wywołanie rysowania dla każdego elementu tablicy
    }
}
