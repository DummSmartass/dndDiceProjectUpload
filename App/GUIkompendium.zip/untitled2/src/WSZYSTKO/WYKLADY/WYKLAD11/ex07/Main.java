package WSZYSTKO.WYKLADY.WYKLAD11.ex07;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

//to samo chyba
public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        VBox root = new VBox();

        Text text = new Text("top");
        TextField tf = new TextField();

        RadioButton rb1 = new RadioButton("opcja1");
        RadioButton rb2 = new RadioButton("opcja2");

        ToggleGroup group = new ToggleGroup();
        rb1.setToggleGroup(group);
        rb2.setToggleGroup(group);

        Button button = new Button("button");

        button.setOnAction(
            e -> System.out.println("tu")
        );

        ChoiceBox cb = new ChoiceBox();
        cb.getItems().addAll("o1", "o2", "o3");

        ListView lv = new ListView(
            FXCollections.observableArrayList("v1","v2","v3")
        );

        root.getChildren().addAll(
            text, tf, rb1, rb2, button, cb, lv
        );

        Scene scene = new Scene(
            root, 300, 250
        );

        stage.setScene(scene);
        stage.setTitle("First FX window");
        stage.show();
    }
}
