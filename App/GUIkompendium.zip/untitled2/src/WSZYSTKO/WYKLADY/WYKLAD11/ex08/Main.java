package WSZYSTKO.WYKLADY.WYKLAD11.ex08;

import javafx.beans.binding.DoubleBinding;
import javafx.beans.binding.NumberBinding;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;

public
    class Main {

    public static void main(String[] args)
    {
        {
        double size = 10;
        double area = size * size;

        System.out.println(area);

        size = 20;

        // powierzchnia nie zmienia się wraz ze zmiennymi z których ją obliczono
        System.out.println(area);
        area = size * size;
        System.out.println(area);
        }
//===============================================================
        {

            DoubleProperty size = new SimpleDoubleProperty(10);
            NumberBinding area = size.multiply(size);

            System.out.println(area.getValue());

            size.set(20);
            System.out.println(area.getValue());
        }
//===============================================================
        {
            //typ złóżony doubleProperty może przechowywać wartości doublowe
            //new SimpleDoubleProperty(10); służy doustawiania wartości DoubleProperty prostym doublem
            DoubleProperty size = new SimpleDoubleProperty(10);

            //NumberBinding area to zmienna zożona z wartoścu unnych zmiennych
            NumberBinding area = new DoubleBinding() {
                {
                    //super.bind(size) wierze element z area z wartością size (jeżeli wartość size sięzmenia to wartość area jest aktualizowana)
                    super.bind(size);
                }

                //computeValue to funkcja określająca wartość elementu
                @Override
                protected double computeValue()
                {
                    return size.get() * size.get();
                }
            };

            System.out.println(area.getValue());

            size.set(20);

            System.out.println(area.getValue());
            // i jak widać wartość area się elesrtyczna i zmenia się wraz z sizem
        }
    }

}
