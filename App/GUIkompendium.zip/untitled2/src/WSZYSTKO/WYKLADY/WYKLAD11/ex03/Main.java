package WSZYSTKO.WYKLADY.WYKLAD11.ex03;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public
    class Main
    extends Application
{
    //rozkłady elementów
    //wolne // można zdefiniować i własnoręcznie określićich lokalizacje
        //Pane
        //Region
        //Group
    //zachowawcze // dbają o to ay elementy na siebie nie zachowziły
        //Hbox
        //Vbox
        //StackPane(naklłada elmenty na siebie zamiast je zasłaniać)
    // Pozycyjne (ustawia siępozyjce (jak było north sout))
        //TilePane
        //Flow Pane
        //AnchorPane
        //GridPane

    @Override
    public void start(Stage stage) throws Exception
    {

        //ustawienie roota jako stack pane(elementy na sobie na środku)
        StackPane root = new StackPane();

        //utworzenie kwadratów
        Rectangle rect1 = new Rectangle( 30, 30, Color.DARKGREEN);
        Rectangle rect2 = new Rectangle( 70, 70, Color.TOMATO);
        Rectangle rect3 = new Rectangle( 90, 90, Color.AQUA);

        //podanie kwadratów(kolejność ma zanczenie (3 na wierzchu))
        root.getChildren().addAll( rect1, rect2, rect3);

        //komeny .toBack i .toFront pozwalają zamienić ich warstwy na maksa do przodu i na maksa do tyłu
        rect3.toBack();
        rect1.toFront();

        Scene scene = new Scene
        (
            root, 300, 250
        );

        stage.setScene(scene);
        stage.setTitle("First FX window");
        stage.show();
    }
}
