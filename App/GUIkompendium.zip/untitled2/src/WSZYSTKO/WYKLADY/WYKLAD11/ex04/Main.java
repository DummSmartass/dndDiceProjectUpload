package WSZYSTKO.WYKLADY.WYKLAD11.ex04;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        //flow pane // elementy są ustawione po sobie
        FlowPane root = new FlowPane( 5, 5);


        for(int i=0; i<5; i++)
            for(int j=0; j<5; j++)
            {
                //randomizacja rozmiaru
                double size = 5 + (30 *Math.random());

                //tworzenie kwadratów o zmiennych kolorach
                Rectangle rect1 = new Rectangle(
                    size,
                    size,

                    (i+j)%2 == 0 ? Color.ORANGE : Color.DARKCYAN
                );

                //dodanie kwadratu do roota(można tworzyć nieskoćżenie wiele elementów w wten sposób)
                root.getChildren().addAll(rect1);
            }

        //scena
        Scene scene = new Scene(
            root, 300, 250
        );

        stage.setScene(scene);
        stage.setTitle("First FX window");
        stage.show();
    }
}
