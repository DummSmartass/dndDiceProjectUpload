package WSZYSTKO.WYKLADY.WYKLAD11.ex06;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        //Vnbox umiescza domyślnie wkolejne elementy pod sobą
        VBox root = new VBox();


        Text text = new Text("top");
        TextField tf = new TextField();

        //Tworzy elementu typu RadioButton (góźiki podobne do checboxów z których można zaznaczać tylko 1)
        RadioButton rb1 = new RadioButton("opcja1");
        RadioButton rb2 = new RadioButton("opcja2");

        //ToggleGroup to grópa Radiobuttonów w ramach którrej tylko jeden może być aktywny na raz
        ToggleGroup group = new ToggleGroup();

        // nie dodaje się góżników do toggle grupy, ustawia się toggle grupe dla każdego góźnika
        rb1.setToggleGroup(group);
        rb2.setToggleGroup(group);

        //tak się tworzy góźik
        Button button = new Button("button");

        //tak ustawia się co ma być zrobione po kliknięciu(set on action) do góźnika
        button.setOnAction
        (
            // e->{} // tak sięustawia akcje wykonywane onAction
            e ->
            {
                System.out.println("tu");
            }
        );

        //choiceBox to to samo co combobox w swingu
        ChoiceBox cb = new ChoiceBox();

        //.getItems().addAll() // pozwala dodawać dowloną ilość elementów (stringów) jako opcje w choiceBoxie
        cb.getItems().addAll("o1", "o2", "o3");

        //listView przyjmuje elementy i wyświetla w formie listy
        ListView lv = new ListView
        (
            // podajesz jako argument z fxowych kolejci widocznąArrayliste i podajesz jej elementy
            FXCollections.observableArrayList("v1","v2","v3")
        );

        //wszystko zapoakowąć
        root.getChildren().addAll
        (
            text, tf, rb1, rb2, button, cb, lv
        );

        Scene scene = new Scene(
            root, 300, 250
        );

        stage.setScene(scene);
        stage.setTitle("First FX window");
        stage.show();
    }
}
