package WSZYSTKO.WYKLADY.WYKLAD11.ex05;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application
{

    @Override
    public void start(Stage stage) throws Exception
    {

        //border pane działa na podobnej zasadzie jak border layout
        BorderPane root = new BorderPane();

        // typ text to po prostu text klóry można wstawić
        Text text = new Text("top");

        //ustawienie jako element górny textu top
        root.setTop(text);

        //ustawienie elementu text będącego topem na pozycji centralnej(w ramach bycia tope,)
        BorderPane.setAlignment( text, Pos.CENTER);

        //ustawianie kierunków kolejnych elementów

        // domyślnie left and right są tak wysoko jak ułożenie im pozwala(jakby nie było top byłybu jeszcze wyrzej)
        root.setLeft(new Text("left"));
        root.setRight(new Text("right"));

        //bottom(jak i top) sadomyślnie maksymalnie na lew(można też zobaczyć, że top i bootm mają "pierwszeństwo" nad left i right)
        root.setBottom(new Text("bottom"));

        // centrum jest w centum
        root.setCenter(new Text("center"));

        Scene scene = new Scene(
            root, 300, 250
        );

        stage.setScene(scene);
        stage.setTitle("First FX window");
        stage.show();
    }
}
