package WSZYSTKO.WYKLADY.WYKLAD11.ex02;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    // stage to element pokazywany
    @Override
    public void start(Stage stage) throws Exception
    {

        // stack pane jako rdzęń domyślinie ustawia wszystko na sobie
        //StackPane root = new StackPane();

        // Group jako rdzęń domyślinie ustawia wszystko w prawym górnym rogu
        //Group root = new Group();

        //VBox root = new VBox(); tworzy rdzeń
        //rdzęń jest głównym komponentem przechowujących komponenty wyświetlane w oknie
        //VBox root ustawia kolejne dodane elementy pod sobą zaczynająć od góry
        VBox root = new VBox();

        //tworzenie kompontów

        //tworzenie kształtu rectagle (warto sprawidzić aby zmienna była z javafx)
        Rectangle rect = new Rectangle( 70, 70, Color.GREEN);
        // przy tworzeniu prostokąta podaje się jego wymiary i kolor

        //tworzenieczeckboxa (warto sprawidzić aby zmienna była z javafx)
        CheckBox box = new CheckBox("Text for checkbox");
        // przy tworzrniu checkboxa ustawia się jego wiadomosć

        //root.getChildren() odwołuje się do kompontów(dzieci) rdzenia czyli wszytstkiego co w nim jest
        //.addAll dodaje nieograniczoną ilość komponentów jako "dzieci" roota
        root.getChildren().addAll( box, rect);

        //scene pozwala wyświetlić roota w stagu
        Scene scene = new Scene
        (
            // w ramach scene podaje się rzeń i wymiary okna
            root, 300, 250
        );

        // na końcu trzeba ustawić stage.setScene(scene) aby ustawić w stage scene
        stage.setScene(scene);

        // tu podaje się nazwe(wyświetlanąw górnym pasku okna)
        stage.setTitle("First FX window");

        // stage.show wyświetla okno
        stage.show();
    }
}
