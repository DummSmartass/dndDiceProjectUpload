package WSZYSTKO.WYKLADY.WYKLAD11.ex01;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    //init jest wykonywana przed rozpoczęciem działania aplikacji
    //służy ona do inicjalizacji narzędzi
    @Override
    public void init() throws Exception {
        super.init();
        System.out.println("init");
    }

    //start wykonywane podczas działania aplikacji
    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("start");

        // Platform.exit(); -- kończy działanie aplikacji
        Platform.exit();
    }

    //stop wyykonywane po zamknięciu aplikacji
    @Override
    public void stop() throws Exception {
        super.stop();
        System.out.println("stop");
    }

}
