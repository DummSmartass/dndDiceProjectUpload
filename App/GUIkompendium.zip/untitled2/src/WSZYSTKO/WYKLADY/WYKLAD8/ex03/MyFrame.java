package WSZYSTKO.WYKLADY.WYKLAD8.ex03;

import WSZYSTKO.WYKLADY.WYKLAD8.data.Student;
import WSZYSTKO.WYKLADY.WYKLAD8.ex02.MyImagePane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        JPanel jp = new JPanel();

        // combox to okienko z wyborem elementów
        JComboBox<Student> jcb = new JComboBox<>(students);
        jp.add(jcb);

        // item listener to klasa abstrakcyjna służąca do wykrywania zmiany w podanym elemęcie
        jcb.addItemListener
        (
            // stworzenie obiektu klasy abstrakcyjnej itemListener
            new ItemListener()
            {
                // nadpisanie itemStateChanged
                @Override
                public void itemStateChanged(ItemEvent e)
                // ItemEvent przenosi informacje o zmianie w stanie lementu np. comboboxa
                {
                    // przepuszcza do wypisania tylko elementy których status zmiany jest selected
                    if(e.getStateChange() == ItemEvent.SELECTED)
                        System.out.println(e);
                }
            }
        );

        add(jp);
    }
}
