package WSZYSTKO.WYKLADY.WYKLAD8.ex03;

import javax.swing.*;

public
    class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            ()->{
                MyFrame jf = new MyFrame();
                jf.setTitle("w08 Frame");
                jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                jf.setSize( 640, 480);
                jf.setVisible(true);
            }
        );

    }
}
