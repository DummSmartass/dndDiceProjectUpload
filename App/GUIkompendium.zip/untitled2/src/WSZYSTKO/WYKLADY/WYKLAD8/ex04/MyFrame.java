package WSZYSTKO.WYKLADY.WYKLAD8.ex04;

import WSZYSTKO.WYKLADY.WYKLAD8.data.Student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        JPanel jp = new JPanel();

        // jlist to lista którą możne byćwyświetlona jako kompnent
        JList<Student> jList = new JList<>(this.students);

        // po dodaniu listy wszystkie jeje elementy są wypisane
        jp.add(jList);

        //addListSelectionListener nasłuchuje kliknięcia na element listy
        jList.addListSelectionListener(
                (e) -> {
                    System.out.println
                    (
                        //.getSelectionModel() - odwołanie się do modelu
                        //odwołanie się do ilości elementów w modelu
                        jList.getSelectionModel().getSelectedItemsCount()
                    );
                }
        );

        add(jp);
    }
}
