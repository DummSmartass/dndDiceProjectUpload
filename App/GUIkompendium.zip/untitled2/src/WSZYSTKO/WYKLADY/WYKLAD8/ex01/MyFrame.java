package WSZYSTKO.WYKLADY.WYKLAD8.ex01;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class MyFrame extends JFrame// rozszerzenie jframa powoduje możliwość używania elementó klasy jak elementów klasy frame
{

    public MyFrame() throws HeadlessException// handles exeption jest wyrzucane kiedy kod wymaga urzycia klawiatury albo myszki, a urządzenie ich nie wspiera
    {
        JPanel jp = new JPanel();
        jp.setBackground(Color.CYAN);

        JLabel jl = new JLabel("MyLabel");
        jp.add(jl);

        JButton jb = new JButton("Click me");
        jp.add(jb);

        JTextField jtf = new JTextField("input text");
        jp.add(jtf);

        // .getContentPane().add(jp) działa praktycznie tak samo jak .add(jp, ale chyba są bardzo żadkie przypadki kiedy sięróżnią
        this.getContentPane().add(jp);

        // action listenery odnoszą się do elementów które można aktywować(mp guzik kliknięciem)
        // dodawanie action listenera do elementu
        jb.addActionListener
        (
            // ActionListener jest abstrakcyjny
            // trzeba nadpisać w nowym actionlistenerze funkcje actionPerformed
            new ActionListener()
            {
                // metoda do nadpisania
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    System.out.println(
                        jtf.getText()
                    );
                }
            }
        );

        // keyListener odbiera informacje z klawiatóty
        jtf.addKeyListener
        (
            // new key adapter to nowa instancja klasy interpretującej input z klawiatury(np jak w tym przypadku jedynie w kontekście okna)
            // keyAdapter jest abstrakcyjny
            new KeyAdapter()
            {
                // metoda do napisania
                @Override
                public void keyTyped(KeyEvent e)
                {
                    // super.keyTyped(e) - ptrzesyła input z klawiatury do metody keytyped z klasy nadrzędnej( jest to odpowiedzialne za zapamiętanie i wyświetlanie wpisanych wartości)
                    super.keyTyped(e);

                    System.out.println
                    (
                        jtf.getText()
                    );
                }
            }
        );
    }
}
