package WSZYSTKO.WYKLADY.WYKLAD8.ex02;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

public
    class MyImagePane
    // jcomponent to klasa po której dziedziczą wszystkie elementy które można dodadać do okna (textfieldy, góziki, teźtarey etc...)
    extends JComponent {

    // zmienna typu image przechowuje obraz;
    private Image bufferedImage;

    public MyImagePane()
    {
        // elementy typu bufferedimage inicjuje sie wraz z podaniem szerokości i wysokości oraz określenia typu zapisu pixeli(w tym przypadku są to integery określające proporcje kolorów Red Green Blue)
        bufferedImage = new BufferedImage( 1000, 1000, BufferedImage.TYPE_INT_RGB);

        //Graphic(wykreśłacz) służy do pokazywania zawartości obrazów(wizualiów)
        //pobranie wykreślacza z grafiki
        Graphics gDC = bufferedImage.getGraphics();

        int size = 2;

        for(int i=0; i<1000; i++)
        {
            for(int j=0; j<1000; j++)
            {
                // warte nadmieninenia ustawienie koloru nie powoduje zmiany kolouru obrazu, jest to po prostu metoda przechowywania go przed kolejnym użyciem
                gDC.setColor
                (
                    new Color(
                        (int)(Math.random()*255),
                        (int)(Math.random()*255),
                        (int)(Math.random()*255)
                    )
                );
                // wypełnianie prostokąta w lokalizacji (x,y)=(i*size, j*size) o szerokości size i wysokości size, o kolorze który został wcześniej ustawiony
                gDC.fillRect( i*size, j*size, size, size);
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        // super.paintComponent(g); - odmalowuje dotychczasowy obraz
        super.paintComponent(g);

        // .drawImage jest funkcją rysującąobraz w podaneej lokacji podawany jest wtedy typ obrazu(bufferedImage),
        // x i y rozpoczęcia (0,0 (jest to poczatek rysunku czyli lewy-górny róg dostępnej przestrzeni))
        // oraz miejsce w którym dany obraz ma być narysowany w tym przypadku obiek tej klasy na którym funkcja jest wykonywana
        g.drawImage( bufferedImage, 0, 0, this);
/*
        int size = 2;
        for(int i=0; i<1000; i++){
            for(int j=0; j<1000; j++){
                g.setColor(
                        new Color(
                                (int)(Math.random()*255),
                                (int)(Math.random()*255),
                                (int)(Math.random()*255)
                        )
                );
                g.fillRect( i*size, j*size, size, size);
            }
        }
 */
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension( 1000, 1000);
    }
}
