package WSZYSTKO.WYKLADY.WYKLAD8.ex02;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public
    class MyFrame
    extends JFrame {

    public MyFrame() throws HeadlessException {
        MyImagePane myImagePane = new MyImagePane();

        // tak tworzy się Jscrollpane stanowiący ruchome okno pokazujące wycinki obrazu zbyt dużego aby w całości zmieścić sie na ekrtanie
        JScrollPane jsp = new JScrollPane(myImagePane);
        // jsp zachowuje się jak obraz, ale można po nim pzesówać

        add(jsp);
    }
}
