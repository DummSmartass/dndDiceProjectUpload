package WSZYSTKO.WYKLADY.WYKLAD8.ex05;

import WSZYSTKO.WYKLADY.WYKLAD8.data.Student;

import javax.swing.*;
import javax.swing.event.ListDataListener;

public
    class StudentModel
    implements ComboBoxModel<Student>
    // model służy do opisania właśniwości elementów zbioru dostarcza dane do komponentu
    //ComboBoxModel<Student> musi implementować metody ComboBoxModel dla obiektów typu student
{

    private Student[] students;

    public StudentModel() {
        this.students = Student.makeStudents();
    }

    private Object selectedItem;

    //ustawienie wybranego elemenet
    @Override
    public void setSelectedItem(Object anItem) {
        selectedItem = anItem;
    }

    //zwraca wybrany element
    @Override
    public Object getSelectedItem() {
        return selectedItem;
    }

    //zwraca iość elementów w comboBoxie
    @Override
    public int getSize() {
        return this.students.length;
    }

    //podaje element na danym indeksie
    @Override
    public Student getElementAt(int index) {
        return this.students[index];
    }

    @Override
    public void addListDataListener(ListDataListener l) {}

    @Override
    public void removeListDataListener(ListDataListener l) {}
}
