package WSZYSTKO.WYKLADY.WYKLAD8.ex05;

import WSZYSTKO.WYKLADY.WYKLAD8.data.Student;

import javax.swing.*;

public
    class StudentView
    extends JPanel
    // studenView rozszerza Jpanel i może być traktowane jak taki
{

    private JLabel sNum;
    private JLabel sName;

    public StudentView() {
        sNum = new JLabel();
        sName = new JLabel();

        this.add( sNum);
        this.add( sName);
    }

    public void setStudent(Student student){
        sNum.setText(""+student.getId());
        sName.setText(student.getName());
    }
}
