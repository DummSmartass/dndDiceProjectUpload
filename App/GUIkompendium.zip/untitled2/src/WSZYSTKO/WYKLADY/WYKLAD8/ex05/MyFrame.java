package WSZYSTKO.WYKLADY.WYKLAD8.ex05;

import WSZYSTKO.WYKLADY.WYKLAD8.data.Student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        JPanel jp = new JPanel();

        // JComboBox<Student> będzie zawierał obiekty typu Student
        JComboBox<Student> jcb = new JComboBox<>();

        // ustawienie modelu JComoboxa(na jakich zasadach działa)
        jcb.setModel
        (
            new StudentModel()// dostarczenie danych warstwą pośrednią
        );

        // ustawienie renderera
        jcb.setRenderer
        (
            // listCellRenderer<Student>(renderuje liste studentów(wyświetla ją pod comoBoxem))
            new ListCellRenderer<Student>()
            {

                StudentView sv = new StudentView();

                // nadpisanie zwrucienia komponentu(elementu) listy
                @Override
                public Component getListCellRendererComponent(JList<? extends Student> list, Student value, int index, boolean isSelected, boolean cellHasFocus) {
                    // jeżeli wartość podana nie jest null ustaw wartość na tąoparto o wartość studenta, zwraca to jpanel
                    if(value != null)
                        sv.setStudent(value);
                    return sv;
                }
            }
        );


        jp.add(jcb);

        jcb.addItemListener
        (
            new ItemListener()
            {
                @Override
                public void itemStateChanged(ItemEvent e) {
                    if(e.getStateChange() == ItemEvent.SELECTED)
                        System.out.println(e);
                }
            }
        );

        add(jp);
    }
}
