package WSZYSTKO.WYKLADY.WYKLAD6.EX1;

import java.awt.*;

public
class Main extends Frame
// rozszerza frame jest framem
{

    public static void main(String[] args) {
        new Main();
    }

    private MyData[] myData;

    public Main(){
        myData = new MyData[5];
        for(int i=0; i<myData.length; i++)
            myData[i] = new MyData( 30, 30+(i*30));
        // wypełnienie tablicy wątkami

        for(int i=0; i<myData.length; i++)
            myData[i].start();
        //uruchomoienie każdego wątku tablicy

        setSize( 640,480);
        setVisible(true);

        new Thread(
                () -> {
                    try {
                        while(!Thread.currentThread().isInterrupted()){
                            repaint();
                            Thread.sleep(33);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
        ).start();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        for(Drawable drawable : myData)
            drawable.draw(g);
        // paint wywyołuje draw dla kążdefo elementu listy

        g.setColor(
                new Color(
                        (int)(Math.random()*255),
                        (int)(Math.random()*255),
                        (int)(Math.random()*255)
                )
        );
        g.fillOval( 610, 440, 20, 20);
        // narysowanie owalu w rogu ze n=zmieniającymi się kolorami(pokazuje szybkość wykonywania się aplikacji)
    }
}
// alt insert - skrót klawiszowy do getterów i setterów
