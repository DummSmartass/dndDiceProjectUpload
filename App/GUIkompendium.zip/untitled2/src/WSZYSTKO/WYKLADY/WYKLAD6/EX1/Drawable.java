package WSZYSTKO.WYKLADY.WYKLAD6.EX1;


import java.awt.*;

public
interface Drawable {

    public void draw(Graphics g);
}
