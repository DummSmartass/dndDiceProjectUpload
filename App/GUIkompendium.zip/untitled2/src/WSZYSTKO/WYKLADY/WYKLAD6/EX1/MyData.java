package WSZYSTKO.WYKLADY.WYKLAD6.EX1;

import WSZYSTKO.WYKLADY.WYKLAD6.EX1.Drawable;

import java.awt.*;

public
class MyData
        extends Thread
        implements Drawable
{

    private int counter;

    private int vx, vy;
    private Color color;

    public MyData(int vx, int vy)
    {
        this.counter = 0;

        this.vx = vx;
        this.vy = vy;
        this.color = new Color(
                (int) (Math.random() * 255),
                (int) (Math.random() * 255),
                (int) (Math.random() * 255)
        );
        // randomowy kolor
    }

    @Override
    public void run()
            // nadoisanie run
    {
        try
        {
            while (!Thread.currentThread().isInterrupted())
            // dopuki thread nie jest naruszony
            {
                counter = (counter + 1) % 300;
                // counter scappowany na 300
                Thread.sleep((int) (Math.random() * 200));
                // randomowe długość snu w karzdym obrocie
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
            //złapało wtjątek wypisz
        }
    }

    @Override
    public void draw(Graphics g)
    {
        g.setColor(color);
        g.fillRect( vx, vy, (int)((200*counter)/100), 20);
        // wypełnia prostokąt i go przedłurza
    }
}