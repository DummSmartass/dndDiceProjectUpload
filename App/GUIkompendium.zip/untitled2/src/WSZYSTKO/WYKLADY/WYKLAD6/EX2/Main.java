package WSZYSTKO.WYKLADY.WYKLAD6.EX2;


public
class Main {

    public static void main(String[] args)
    {
        // ustawienie thredów
        Runner r1 = new Runner('!');
        Runner r2 = new Runner('@');
        Runner r3 = new Runner('#');

        // połączenie thredów aby sięzapętlały
        r1.setNext(r2);
        r2.setNext(r3);
        r3.setNext(r1);

        // zainicjowanie wykonania WSZYSTKICH threadów, puki co nie będących obudzonym
        r1.start();
        r2.start();
        r3.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (r1) {
            r1.notify();
        }
    }
}

