package WSZYSTKO.WYKLADY.WYKLAD6.EX2;

public
class Runner
    extends Thread {
    // rorszerza thread(czyli jakby był threadem)

    private char ch;

    private Thread next;
    // następny thread do wykonania

    public Runner(char ch)
    {
        this.ch = ch;
    }

    public void setNext(Thread next)
    {
        this.next = next;
    }

    @Override
    public void run()
    {
        // synchronizuje obecny wątek(daje dostęp do zarzaanie wykonywaniem elementu )
        synchronized (this)
        {
            try {
                wait();
                // uruchamia obcje wait, czekającej na naruszenie
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        for(int i=0; i < 20; i++) {
            System.out.print(ch);

            synchronized (next)
            {
                next.notify();
                //
            }
            synchronized (this){
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

