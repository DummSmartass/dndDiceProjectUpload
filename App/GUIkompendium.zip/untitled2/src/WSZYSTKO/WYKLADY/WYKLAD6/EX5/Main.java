package WSZYSTKO.WYKLADY.WYKLAD6.EX5;

import java.util.concurrent.*;
// pozwala łatwo zarządać wieloma wątkami

public
class Main
{
    public static void main(String[] args)
    {
        // Elment typu ExecutorService ma przypisane
        //Executors.newFixedThreadPool(10) czyli "tablice" 10 threadów którymi będzie zarządał
        ExecutorService es = Executors.newFixedThreadPool(10);

        // es.submit rozpoczyna podanego elementu rozszerzającego runnable lub callable
        es.submit
        (
            // thread ma tylko jedną metode, więc można urzyćlambdy do przekazania threada
            () ->
            {
                for(int i=0; i<10; i++)
                    System.out.print('b');
            }
        );

        // es.execute rozpoczyna podanego elementu rozszerzającego runnable
        es.execute
        (
            ()->
            {
                for(int i=0; i<10; i++)
                    System.out.print('a');
            }
        );

        // kończy wykonywanie wątków
        es.shutdown();
    }
}
