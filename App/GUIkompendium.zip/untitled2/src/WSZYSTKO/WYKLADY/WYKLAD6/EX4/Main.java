package WSZYSTKO.WYKLADY.WYKLAD6.EX4;

public
    class Main {

    public static void main(String[] args) {
        Thread sleeper = new Thread()
        {
            @Override
            public void run()
            {
                long time = System.currentTimeMillis();
                try
                {
                    Thread.sleep(3000);
                    System.out.println("I have slept");
                }
                catch (InterruptedException e)
                {
                    System.out.println
                    (
                        "Sleeping time = " +
                        (System.currentTimeMillis() - time) +
                        " ms"
                    );
                }
            }
        };

        sleeper.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        sleeper.interrupt();

        // jeżeli wątek nigdy nie zostaje przerwany wykonianie kończy siębłędem
        //sleeper.start();
    }
}
