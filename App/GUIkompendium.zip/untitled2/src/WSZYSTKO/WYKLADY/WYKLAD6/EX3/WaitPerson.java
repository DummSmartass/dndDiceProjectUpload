package WSZYSTKO.WYKLADY.WYKLAD6.EX3;

public
    class WaitPerson
    extends Thread {

    private Restaurant restaurant;

    public WaitPerson(Restaurant restaurant) {
        this.restaurant = restaurant;
        start();
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()){
            while(restaurant.order == null)
                synchronized (this){
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            System.out.println(
                "WaitPerson got " + restaurant.order
            );
            restaurant.order = null;
        }
    }
}
