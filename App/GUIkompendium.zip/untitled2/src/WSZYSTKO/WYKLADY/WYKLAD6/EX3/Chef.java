package WSZYSTKO.WYKLADY.WYKLAD6.EX3;

public
    class Chef
    extends Thread {

    private Restaurant restaurant;
    private WaitPerson waitPerson;

    public Chef(Restaurant restaurant, WaitPerson waitPerson) {
        this.restaurant = restaurant;
        this.waitPerson = waitPerson;
        start();
    }

    @Override
    public void run() {
        while(!Thread.currentThread().isInterrupted()){
            if(restaurant.order == null) {
                restaurant.order = new Order();
                System.out.println("Order up!");
                // synchronize pozwala uruchamiać wątki w innych klasach
                synchronized (waitPerson){
                    waitPerson.notify();
                }
            }
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
