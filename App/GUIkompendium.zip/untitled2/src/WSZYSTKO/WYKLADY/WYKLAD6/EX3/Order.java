package WSZYSTKO.WYKLADY.WYKLAD6.EX3;

public
    class Order {

    private static int number = 0;

    private int count;

    public Order() {
        this.count = number++;
        if(this.count == 10){
            System.out.println("Out of food, closing");
            System.exit(0);
        }
    }

    @Override
    public String toString() {
        return "Order" + count;
    }
}
