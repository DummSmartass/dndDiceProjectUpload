package WSZYSTKO.WYKLADY.WYKLAD7.EX2;

import javax.swing.*;
import java.awt.*;

public
class MyBorderJPanel extends JPanel
// rozszerzanie Jpanelu oznacza, że element jest traktowany jak jpanel
{
    public MyBorderJPanel()
    {
        setLayout(new BorderLayout());

        add( new JButton("PS"), BorderLayout.PAGE_START);
        add( new JButton("PE"), BorderLayout.PAGE_END);
        add( new JButton("LS"), BorderLayout.LINE_START);
        add( new JButton("LE"), BorderLayout.LINE_END);
    }
}
