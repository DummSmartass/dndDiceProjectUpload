package WSZYSTKO.WYKLADY.WYKLAD7.EX2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public
    class Main {

    public static void main(String[] args)
    {
        // jest po prstu potrzebne w swingu
        SwingUtilities.invokeLater(
            // ustawienie lamdą swinga(tak możńa)
            ()->{
                // stworzenie jframa
                JFrame jFrame = new JFrame();

                // ustawienie zamykania okna w czasie zamykania
                jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // ustawienia wartośći
                jFrame.setSize( 640, 480);

                // ustawienia czy
                jFrame.setVisible(true);

                JButton jb = new JButton("Click me");
                // tak dodaje się
                jb.addActionListener
                (
                    // nowy actionlistener
                    new ActionListener()
                    {
                        //nadpisanie actionPerformed
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.out.println("click");
                        }
                    }
                );

                // ustawienie leyaoutu
                jFrame.setLayout(new BorderLayout());

                //jFrame.getContentPane().add(jb);
                jFrame.add(new MyFlowLayout(), BorderLayout.CENTER);
/*
                jFrame.add(jb, BorderLayout.NORTH);
                jFrame.add(jb, BorderLayout.SOUTH);
                jFrame.add(jb, BorderLayout.EAST);
                jFrame.add(jb, BorderLayout.WEST);
*/
                jFrame.add( jb, BorderLayout.PAGE_START);
                // ustawienie elementu na początku strony
                jFrame.add( new MyBorderJPanel(), BorderLayout.PAGE_END);
                // dodanie elementu na końcu strony

                //jFrame.add( jb, BorderLayout.LINE_START);
                //jFrame.add( jb, BorderLayout.LINE_END);
            }
        );
    }
}
