package WSZYSTKO.WYKLADY.WYKLAD7.EX2;

import javax.swing.*;
import java.awt.*;

public class MyFlowLayout extends JPanel
// rozszerzanie Jpanelu oznacza, że element jest traktowany jak jpanel
{
    public MyFlowLayout()
    //kreator
    {
        setLayout(new FlowLayout());
        // ustalanie typu leyaoput

        for(int i=0; i<10; i++)
            // dodawanie kolejnych góźników
            add( new JButton("Button "+i));
    }
}
