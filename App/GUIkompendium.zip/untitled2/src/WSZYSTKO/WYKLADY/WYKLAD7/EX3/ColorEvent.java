package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

import java.awt.*;
import java.util.EventObject;

public class ColorEvent extends EventObject
// rozszerzenie EvenObject powoduje, że element jest traktowany jak eventObject
{

    private Color color;

    public ColorEvent(Object source, Color color)
    {
        // odwołuje się do klasy obiektu który jest zmieniany
        super(source);
        // dokonuje zmaian w obiekcie source
        this.color = color;
    }

    public Color getColor() {
        return color;
    }
}
