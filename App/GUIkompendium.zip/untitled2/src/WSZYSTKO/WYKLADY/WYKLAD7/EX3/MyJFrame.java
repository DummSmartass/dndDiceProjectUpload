package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

import javax.swing.*;
import java.awt.*;

public class MyJFrame extends JFrame {

    public MyJFrame()
    {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MyGenerator myGenerator = new MyGenerator();

        MyColorJPanel mcjp1 = new MyColorJPanel();

        myGenerator.addColorListener(mcjp1);

        MyColorJPanel mcjp2 = new MyColorJPanel();

        myGenerator.addColorListener(mcjp2);

        JPanel centerPanel = new JPanel();
        centerPanel.add(mcjp1);
        centerPanel.add(mcjp2);

        this.setSize( 640, 480);

        this.add(centerPanel);
        this.setVisible(true);
    }
}
