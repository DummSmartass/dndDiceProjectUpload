package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

public interface ColorListener {

    void colorChange(ColorEvent evt);
    // interface posiadający funkcje z argumentem typu colorEvent
}
