package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

import javax.swing.*;

public
    class Main {

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater
        (
            // można wypełnić SwingUtilities.invokeLater  za pomocą lamdy do nowostworzonego elementu MyJframe
            () -> new MyJFrame()
        );
    }
}
