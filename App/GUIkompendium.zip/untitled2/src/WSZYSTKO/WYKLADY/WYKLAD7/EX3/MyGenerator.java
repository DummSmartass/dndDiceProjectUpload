package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

import java.awt.*;
import java.util.ArrayList;

public class MyGenerator extends Thread{

    public MyGenerator() {
        this.start();
    }

    @Override
    public void run() {
        while(!Thread.currentThread().isInterrupted()){
            Color color = new Color(
                (int)(Math.random()*255),
                (int)(Math.random()*255),
                (int)(Math.random()*255)
            );
            ColorEvent ce = new ColorEvent( this, color);
            fireColorChange(ce);

            try{
                Thread.currentThread().sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // arrayie przechowująće elementy oznaczone nazwą interfejsu mogą przechwywać elementy klas implementujących ten interfejs
    private ArrayList<ColorListener> al = new ArrayList<>();

    public void addColorListener(ColorListener cl){
        al.add(cl);
    }

    private void fireColorChange(ColorEvent evt){
        synchronized (this)
        {
            for(ColorListener cl : al)
                cl.colorChange(evt);
        }
    }

}
