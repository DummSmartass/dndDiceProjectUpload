package WSZYSTKO.WYKLADY.WYKLAD7.EX3;

import javax.swing.*;
import java.awt.*;

public
    class MyColorJPanel
    extends JPanel
    implements ColorListener{

    private Color color;

    public MyColorJPanel()
    {
        // randomizacja koloru
        this.color = new Color
        (
            (int)(Math.random()*255),
            (int)(Math.random()*255),
            (int)(Math.random()*255)
        );
        // ustawianie koloru jako backgroundu
        this.setBackground(this.color);

        // domyśłna wielkość
        this.setPreferredSize(
            new Dimension(200, 200)
        );
    }

    @Override
    public void colorChange(ColorEvent evt)
    {
        this.setBackground(evt.getColor());
        // repaint to oświerzenie obrazu
        repaint();
    }
}
