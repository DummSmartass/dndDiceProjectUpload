package WSZYSTKO.WYKLADY.WYKLAD7.EX1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
// potrzebne importy

public
class Main
{
    public static void main(String[] args)
    {
        // awt nie jest w invoke later
        Frame f = new Frame();
        f.setSize( 640, 480);
        //f.setVisible(true);

        //addWindowlistener dodaje windowListener
        f.addWindowListener
        (
            // klasa windowadapter implementuje wszystkie metody windolistener
            new WindowAdapter()
            {
                // nadpisuje windowClosing
                @Override
                public void windowClosing(WindowEvent e)
                {
                    super.windowClosing(e);
                    // odowłanie do nadrzędnej funkcji
                    System.exit(0);
                }
            }
        );

        //SwingUtilities.invokeLater przyjmuje wątek wykonywany podczas wywoływania zmiennej
        SwingUtilities.invokeLater
        (
            ()->{
                JFrame jFrame = new JFrame();
                jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                jFrame.setSize( 640, 480);
                jFrame.setVisible(true);
            }
        );
    }
}
