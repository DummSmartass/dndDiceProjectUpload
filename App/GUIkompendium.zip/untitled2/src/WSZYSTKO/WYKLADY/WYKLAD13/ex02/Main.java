package WSZYSTKO.WYKLADY.WYKLAD13.ex02;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.effect.Reflection;
import javafx.scene.effect.Shadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.util.Date;

public
    class Main
    extends Application {

    private final Text textTime = new Text();
    private volatile boolean programEnd = false;
    Thread timer = new Thread(
        ()->{
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");

            while(!programEnd)
            {

                String time = sdf.format(new Date());

                //nie wiem po co to działa be runLater
                Platform.runLater
                (
                    () -> textTime.setText(time)
                );

                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    );

    @Override
    public void start(Stage stage) throws Exception {
        BorderPane root = new BorderPane();
        root.setCenter(textTime);

        Stop[] stops = new Stop[]{
                new Stop( 0, Color.BLACK),
                new Stop( 0.5, Color.YELLOW),
                new Stop( 0.8, Color.AQUAMARINE),
                new Stop( 1, Color.DEEPPINK)
        };

        LinearGradient gradient = new LinearGradient(
                0, 0, 180, 0, false,
                CycleMethod.NO_CYCLE, stops
        );

        textTime.setFont(Font.font("Verdana", 70));
        textTime.setFill(gradient);

        textTime.setEffect(new Shadow());

        Reflection reflection = new Reflection();
        reflection.setTopOffset(5);
        reflection.setFraction(0.8);
        reflection.setTopOpacity(0.05);
        reflection.setBottomOpacity(0.5);

        textTime.setEffect(reflection);

        Scene scene = new Scene( root, 640, 480);
        stage.setScene(scene);
        stage.show();

        timer.start();
    }

    @Override
    public void stop() throws Exception
    {
        //zatrzymanie wszystkioego
        super.stop();
        // zmiana końcaprogramu na koniec
        programEnd = true;
    }
}
