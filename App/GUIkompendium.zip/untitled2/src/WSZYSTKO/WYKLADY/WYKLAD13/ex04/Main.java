package WSZYSTKO.WYKLADY.WYKLAD13.ex04;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Random;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        //generuje Arrayliste widzialnych elementów(na podstawie takiego elementu można wyświetlać liste elementów w oknie )
        ObservableList<Integer> items = FXCollections.observableArrayList(
            10, 20, 50, 80, 100
        );

        // list view pozwala wyświetlać obserwable list(podanąjako argument)
        ListView<Integer> listView = new ListView<>(items);

        //listView.getSelectionModel().selectedIndexProperty().addListener dodaje listener do wyboru indexu
        listView.getSelectionModel().selectedIndexProperty().addListener(
            TuMożeByćNapisaneCOKOLWIEKITAKZADZIAŁANIEPRZEJMUJCIESIETYM ->
            {
                System.out.println
                (
                    //zwraca numer wybranego indexui
                    listView.getSelectionModel().getSelectedIndex()
                );
            }
        );

        Button button = new Button("Add");

        //co ma sięstać po naciśnięciu
        button.setOnAction
        (
            dupa -> items.add /*nie potrzeba klamerek jak jest tylko jedna linijka*/
            (
                // nowy randomowy.integer(w zaksie 0-100)
                new Random().nextInt(100)
            )
        );

        items.addListener
        (
            //dodawany do listy changelistener wykonuje podane akcje w momęcie zajścia jakiejkolwiek zmiany w elemeńcie
            new ListChangeListener<Integer>()
            {
                //to jakąś metodą produkuje wiadomość
                @Override
                public void onChanged(Change<? extends Integer> change) {
                    System.out.println(change);
                }
            }
        );

        VBox root = new VBox(listView, button);

        Scene scene = new Scene( root, 640, 480);
        stage.setScene(scene);
        stage.show();
    }
}
