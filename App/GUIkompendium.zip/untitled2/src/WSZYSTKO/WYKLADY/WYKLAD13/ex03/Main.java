package WSZYSTKO.WYKLADY.WYKLAD13.ex03;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception
    {
        Circle circle = new Circle( 50, 150, 50, Color.DEEPPINK);

        Pane root = new Pane(circle);

        //scene można stworzyć w ten sposób
        Scene scene = new Scene( root, 640, 480);

        stage.setScene(scene);
        stage.show();


        //kułko.zmianaZmiennejX o 200
        KeyValue posXStart = new KeyValue(circle.translateXProperty(), 200);
        KeyValue posYEnd = new KeyValue(circle.translateYProperty(), 200);

        KeyFrame startKF = new KeyFrame
        (
            // wykonaj akcje w labdzie po zakończeniu, przesówaj się przez pięć sekund o wartość podaną w zmiennej typu keyValue
            //(czas twrania, akcja po zakończneiu czasu,wektor do pokonania)
            Duration.seconds(5),
            e -> {
                circle.setFill(Color.GREEN);
            },
            posXStart
        );


        KeyFrame endKF = new KeyFrame
        (
            // przez 10 sekund wykonuj wektor (czas, wektor do pokonania w tym czasie)
            Duration.seconds(10), posYEnd
        );

        //timeline to zmienna przechowująca wydarzenia do wykonania
        Timeline tl = new Timeline(
            startKF, endKF
        );

        //przez to animacja nigdy się nie skoćńczy
        tl.setCycleCount(Timeline.INDEFINITE);

        //to spowduje, że po zakończeniu elementy bęą wracaćpo własnych krokach
        tl.setAutoReverse(true);

        // uruchamia animacje
        tl.play();
    }
}
