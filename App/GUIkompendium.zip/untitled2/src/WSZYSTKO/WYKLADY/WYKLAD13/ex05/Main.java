package WSZYSTKO.WYKLADY.WYKLAD13.ex05;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.awt.*;
import java.util.Random;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        //obserwowalna lista może przechowywać kolory
        ObservableList<ColorSelect> items = FXCollections.observableArrayList(
            new ColorSelect("Red")
        );

        //.addAll(jak zwykle wrzuca wzystkie podane elementy)
        items.addAll(
            new ColorSelect("Green"),
            new ColorSelect("Blue")
        );

        ListView<ColorSelect> listView = new ListView<>(items);

        //setCellFactory jest odpowiedzialny za renderig każdego elementu indywidualnie
        listView.setCellFactory
        (
            // Przyjmuje ListView jako argument
            (ListView<ColorSelect> par) ->
                //nowaKlatka(wyrenderowana)
                new ListCell<ColorSelect>()
                {
                    @Override
                    protected void updateItem(ColorSelect colorSelect, boolean b) {
                        //super.updateItem(colorSelect, b);

                        //jak nie ma to nie ma
                        if(colorSelect == null)
                        {
                            setText(null);
                            setGraphic(null);
                        }
                        else
                        {
                            //text jest ustawiaony na toString
                            setText(colorSelect.toString());

                            //ustawia wybrany kolor który może rozpoznać ze stringa
                            //grafika jest przed tekstem niezależnie od orientacji w kodzie
                            setGraphic
                            (
                                new Rectangle
                                (
                                    30, 30, Color.web(colorSelect.getColor())
                                )
                            );
                        }
                    }
                }
        );

        VBox root = new VBox(listView);

        Scene scene = new Scene( root, 640, 480);
        stage.setScene(scene);
        stage.show();
    }
}
