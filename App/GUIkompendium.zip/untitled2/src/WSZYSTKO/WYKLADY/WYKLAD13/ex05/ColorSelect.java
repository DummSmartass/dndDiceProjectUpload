package WSZYSTKO.WYKLADY.WYKLAD13.ex05;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

public
    class ColorSelect {

    String color;
    BooleanProperty isSelected;

    public ColorSelect(String color)
    {
        this.color = color;

        //new simple boolean property przypisuje wartość booleana do podanej zmiennej
        this.isSelected = new SimpleBooleanProperty(false);
    }

    //nadpisany toString jest metodąwyświetlania elementu wprzez dynamiczną liste
    @Override
    public String toString() {
        return color+"["+isSelected.get()+"]";
    }

    public String getColor() {
        return color;
    }
}
