package WSZYSTKO.WYKLADY.WYKLAD13.ex01;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.util.Date;

public
    class Main
    extends Application {

    private final Text textTime = new Text();


    @Override
    public void start(Stage stage) throws Exception
    {

        BorderPane root = new BorderPane();
        root.setCenter(textTime);

        //zmienna simple data fromat przechowuje czas
        // wkonstruktorze podawany jest format w tym przypadku godziny, minuty,sekundy
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");

        //przypisuje do stringa wartość nowozainicjowanej zmiennej daty wyciągająć zawartośc jej formatu
        String time = sdf.format(new Date());

        Stop[] stops = new Stop[]{
                new Stop( 0, Color.BLACK),
                new Stop( 0.5, Color.YELLOW),
                new Stop( 0.8, Color.AQUAMARINE),
                new Stop( 1, Color.DEEPPINK)
        };

        LinearGradient gradient = new LinearGradient(
                0, 0, 180, 0, false,
                CycleMethod.NO_CYCLE, stops
        );

        //można ustawićczcionke i wielkość liter
        textTime.setFont(Font.font("Verdana", 70));
        //text trż może mięćgradient
        textTime.setFill(gradient);

        //reflection odbija obecnie istniejaće obiekty
        Reflection reflection = new Reflection();

        // przesunięcie do góry
        reflection.setTopOffset(5);

        // ułamek który zostanie odbicie
        reflection.setFraction(0.8);

        // ustawienie przezroczystości(im mniejsza tym bardziej przezroczyste) na górze napuisu
        reflection.setTopOpacity(0.05);

        //ustawienie przezroczytości na dole napisu
        reflection.setBottomOpacity(0.5);

        // ustawienie elfektu dla textu
        textTime.setEffect(reflection);

        textTime.setText(time);


        Scene scene = new Scene( root, 640, 480);
        stage.setScene(scene);
        stage.show();
    }
}
