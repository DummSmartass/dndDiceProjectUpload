package WSZYSTKO.WYKLADY.WYKLAD3.EX1;

public
class Student
        implements Comparable<Student>
        // Comparable to interface dostępny w bibliotekach javy
        //<Student> oznacza, że lementy porówneywane bęą typu student
{

    protected String name;
    protected int id;
    // protected pozwala na dostęp do elementu w funkcjach dziedziczących

    public Student(String name, int id)
    {
        this.name = name;
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public int getId()
    {
        return id;
    }

    @Override
    // nadpsianie toString tengo typu nadpisanie powoduje, że np. próba wyświetlenia tego obiektu w który toString jest nadpisanie poskutkuje wywołaniem nadpisanej funkcji toString zamiast standardowej
    public String toString()
    {
        return "Student{" + name + " " + id + "}";
    }

    @Override
    // comparable jest funkcją z intefacu comparable, przyjmuje ona podany obiekt(w naszym przypadku obiekt danjej klasy) i posównuje go z obiektnem na którym funkcja jest wykonywana
    // comparTo jest niezbęne do np sortowania
    public int compareTo(Student o)
    {
        return this.id - o.id;
    }
}
