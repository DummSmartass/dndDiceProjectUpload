package WSZYSTKO.WYKLADY.WYKLAD3.EX1;

import java.util.Arrays;
import java.util.Comparator;

public
class Main {

    public static void main(String[] args) {
        Student[] arr = {
                new Student( "Sylvia", 2),
                new Student( "Philipa", 67),
                new Student( "Hugh", 535)
                // wypełnianie arraya Studenta bez tworzenia zmiennych poza nim
        };

        Arrays.sort(arr);
        //Arrays.sort odnosi się do klasy z biblioteki javy zawierającej metode .sort(sortującej tabele biorąc jako punkt odniesienia wartości zwracane z comapreTo())
        // sort jest możliwe dizęki nadpisaniu compareTo

        System.out.println
        (
                Arrays.toString(arr)
                // Arrrays.toString wypisuje toStringi kolejnych lementów tablicy po przecinku
        );

        Arrays.sort(arr,
                new Comparator<Student>()
                // Można wywołująć metode Arrays.sort ma wariant z dwoma argumentami, gdzie można dostarczyć komparatpr
                {


                    @Override
                    public int compare(Student o1, Student o2) {
                        return o1.getId() - o2.getId();
                    }
                    // nadpisanie metody compare z komparatora, nie jest to to samo co metoda comateTo, pszyjmuje od razu dwie zmiennej i rozszerza Comparator nie Comparable
                }
        );
    }

}

