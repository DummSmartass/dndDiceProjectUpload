package WSZYSTKO.WYKLADY.WYKLAD3.EX2;

public
class MyElement<T>
// MyElement<T> oznacza, że MyElment będzie dowolnego podanego typu, T może być boolean, String int a nawet Student, ma dziąłać na wszyskto wszystkie odowłania do T będą odnosić siędo tego typu
{

    private T value;
    // element podanego typu
    private MyElement<T> next;
    // elemtnt typu Klasy MyElemtn dla typu T

    public MyElement(T value)
    {
        this.value = value;
        this.next = null;
    }
    // ustawienie wartości na poaną wartość dowolnego typu
    // ustawienie wartośći next na null

    public T getValue() {
        return value;
    }

    public MyElement<T> getNext() {
        return next;
    }
    // zwraca obiekt typu MyElment<T> siezący w zmiennej next

    public void setNext(MyElement<T> next) {
        this.next = next;
    }
    // ustawia kolejny lement
}
