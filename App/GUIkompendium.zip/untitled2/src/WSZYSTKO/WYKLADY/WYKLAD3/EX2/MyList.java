package WSZYSTKO.WYKLADY.WYKLAD3.EX2;

public
class MyList<T>
{
    // klasa My List przyjmuje zmiennej podanego typu

    MyElement<T> head;
    // głowa listy to Element MyELementu

    public void add(T value)
    {
        MyElement<T> tmp = new MyElement<>(value);
        // tworzenie nowego elementu MyElement (zauważ, że new MyElment<>(value) nie wymaga podania typu bo typ jest już wybarny)
        tmp.setNext(this.head);
        // obecna głowa wraz przenozona jest do zmiennej next
        this.head = tmp;
        // nowy element listy zajmuje jej miejsce
    }
    // stos

    public MyElement<T> getHead() {
        return head;
    }
    // zwraca obecnągłowe
}