package WSZYSTKO.WYKLADY.WYKLAD3.EX2;


import WSZYSTKO.WYKLADY.WYKLAD3.EX1.Student;
// tak można uzyskać dostęp do wybranych plków w javie

import java.util.LinkedList;

public
class Main {

    public static void main(String[] args)
    {
        MyElement<Student> el = new MyElement<>(new Student("Hugh", 535));
        // typ jest deklarowany w zmiennej
        // Tworzymy element studenta

        Student tmp = el.getValue();
        //pobieramy wartosć z studenta


        MyList<Student> list = new MyList<>();
        // MyLista typu st=student
        list.add(tmp);
        // tworzymy liste i podajemy wartość tmp jako argument

        Student stu = list.getHead().getValue();
        // pobieramy wartość z głowy listy

        LinkedList<Student> ll = new LinkedList<>();
        ll.add(tmp);

        // na ll można robić to co na zwykłej liście

    }
}
