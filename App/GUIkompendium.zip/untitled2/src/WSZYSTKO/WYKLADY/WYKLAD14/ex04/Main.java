package WSZYSTKO.WYKLADY.WYKLAD14.ex04;

import WSZYSTKO.WYKLADY.WYKLAD2.EX3.A;
import javafx.application.Application;
import javafx.geometry.Point3D;
import javafx.scene.*;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.DrawMode;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.awt.event.KeyEvent;

public class Main extends Application
{
    @Override
    public void start(Stage stage) throws Exception
    {

        Cylinder cylinder = new Cylinder(40,120);

        //ustawia cylinder w 3d przestrzeni
        cylinder.setTranslateX(300);
        cylinder.setTranslateY(300);
        cylinder.setTranslateZ(0);

        //punkt względem którego obiekt jest zrotowany
        cylinder.setRotationAxis(new Point3D(100,100,0));

        //zmiana promienia cylindra
        cylinder.setRadius(10);

        // przechowuje kolor i jego odcienie ???
        PhongMaterial colorMat =new PhongMaterial();

        //ustawienie koloru naświetlonego i wcieniowanego
        colorMat.setDiffuseColor(Color.FORESTGREEN);
        colorMat.setSpecularColor(Color.LIMEGREEN);

        cylinder.setMaterial(colorMat);//ustawienie materiału danego koloru
        cylinder.setDrawMode(DrawMode.LINE);//wybrany typ rysowania

        //Ambientlight to rodzaj oświetlenia //to światło służy do resetowania oświetlenia
        AmbientLight ambientLight = new AmbientLight
                (
                        //.web pobiera kolor z kexadecymalnego w stringu
                        Color.web("0x404040")
                );

        //
        PointLight pointLight = new PointLight
                (
                        Color.web("0xffcc33")
                );
        //ustawienie lokalizacji
        pointLight.setTranslateX(400);
        pointLight.setTranslateY(300);
        pointLight.setTranslateZ(-200);

        //kamera
        //false (nie jest unieruchomiona w punkcie 0,0,0)
        PerspectiveCamera camera = new PerspectiveCamera(false);

        //lokalizacja kamery
        camera.setTranslateX(0);
        camera.setTranslateY(0);
        camera.setTranslateZ(-500);

        Group root = new Group(cylinder,ambientLight/*można dodać oświetlenie jako komponent*/,pointLight);
        Scene scene = new Scene( root, 640, 480);

        //urzycie alternatywnej kamery
        scene.setCamera(camera);

        scene.setOnKeyPressed
                (
                        //keyEvent to zmienna reprezentująca naciśnięty klawisz(jest ona jedynm imputem w tej "lambdzie")
                        keyEvent ->
                        {
                            switch (keyEvent.getCode())/*.getCode w przypadku keyEventu zwraca wartość charową wciśniętego przycisku(wciskasz klawisz w .getCode zwraca w)*/ {
                                case W -> camera.setTranslateZ(camera.getTranslateZ() + 10); //przesunięcie kamery o 10
                                case S -> camera.setTranslateZ(camera.getTranslateZ() - 10);
                                case A -> camera.setTranslateX(camera.getTranslateX() + 10);
                                case D -> camera.setTranslateX(camera.getTranslateX() - 10);

                                //Up i down zymbolizują strzałki do góry i w dół
                                case UP -> camera.setTranslateY(camera.getTranslateY() + 10);
                                case DOWN -> camera.setTranslateY(camera.getTranslateY() - 10);
                            }
                        }
                );

        stage.setScene(scene);
        stage.show();
    }
}
