package WSZYSTKO.WYKLADY.WYKLAD14.ex01;

import java.util.Map;

public
    class Main {

    //Warto se mapy przypomnieć

    //wypisywanie lementów
    public static void main(String[] args)
    {
        //Mapa Zawieraj aca watek i tablice stacktrace
        //funkcja Thread.getAllStackTraces() zwraca mape tego typu zawierającą informacje o Threadach
        Map<Thread, StackTraceElement[]> map =  Thread.getAllStackTraces();

        //iteracja po mapie threadów
        for(Map.Entry<Thread, StackTraceElement[]> ent : map.entrySet())
        {
            //nazwa Threadu
            System.out.println(ent.getKey().getName());
            //Wartość
            //przepuszczenie przez funkcje format
            System.out.println(format(ent.getValue()));
        }
    }

    private static String format(StackTraceElement[] arr)
    {
        StringBuffer sb = new StringBuffer("StackTrace: ");

        for(StackTraceElement el : arr)
            sb.append("\n at ")
            .append(el.toString());
        sb.append("\n");

        return sb.toString();
    }
}
