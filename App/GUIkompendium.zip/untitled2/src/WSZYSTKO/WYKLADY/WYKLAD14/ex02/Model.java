package WSZYSTKO.WYKLADY.WYKLAD14.ex02;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Map;

public
    class Model {

    private ObservableList<String> threadsNames;
    private ObservableList<String> stackTraces;

    public Model() {
        this.threadsNames = FXCollections.observableArrayList();
        this.stackTraces = FXCollections.observableArrayList();
        update();
    }

    //tworzenie
    public void update(){
        this.threadsNames.clear();
        this.stackTraces.clear();

        Map<Thread, StackTraceElement[]> map =  Thread.getAllStackTraces();

        for(Map.Entry<Thread, StackTraceElement[]> ent : map.entrySet()){

            this.threadsNames.add(ent.getKey().getName()
            );
            this.stackTraces.add(
                format(ent.getValue())
            );
        }
    }

    //wypełnianie
    private String format(StackTraceElement[] arr){
        StringBuffer sb = new StringBuffer("StackTrace: ");
        for(StackTraceElement el : arr)
            sb.append("\tat ")
                    .append(el.toString())
                    .append("\n");
        return sb.toString();
    }

    public ObservableList<String> getThreadsNames() {
        return threadsNames;
    }

    public ObservableList<String> getStackTraces() {
        return stackTraces;
    }
}
