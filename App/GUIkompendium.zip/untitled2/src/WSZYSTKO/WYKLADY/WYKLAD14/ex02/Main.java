package WSZYSTKO.WYKLADY.WYKLAD14.ex02;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Map;

public
    class Main
    extends Application {

    private ListView<String> listView;
    private TextArea stackTraceArea;
    private Button updateButton;

    private Model model;

    public Main(){
        this.model = new Model();
    }

    @Override
    public void start(Stage stage) throws Exception {
        listView = new ListView<>(model.getThreadsNames());
        stackTraceArea = new TextArea();
        updateButton = new Button("Update");

        //update w momęcie wciśnięcia
        updateButton.setOnAction
        (
            actionEvent -> model.update()
        );

        listView.getSelectionModel().selectedIndexProperty().addListener
        (
                //kiedy zajdzie zmiana w wybranym elemęcie
            change ->
            {
                Platform.runLater
                (
                    ()->
                    {
                        //pobiera index
                        int index = listView.getSelectionModel().getSelectedIndex();

                        //sprawdzenie czy index istnieje
                        if(index >= 0)
                            //podaje wynik i wyświetla go w arei
                            stackTraceArea.setText
                            (
                                model.getStackTraces().get(index)
                            );
                    }
                );
            }
        );

        VBox root = new VBox( listView, stackTraceArea, updateButton);

        Scene scane = new Scene( root, 640, 480);

        stage.setScene(scane);
        stage.show();
    }
}
