package WSZYSTKO.WYKLADY.WYKLAD14.ex03;

import javafx.application.Application;
import javafx.geometry.Point3D;
import javafx.scene.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.DrawMode;
import javafx.stage.Stage;

public
    class Main
    extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        Cylinder cylinder = new Cylinder(40, 120);
        cylinder.setTranslateX(300);
        cylinder.setTranslateY(300);
        cylinder.setTranslateZ(0);
        cylinder.setRadius(10);
        cylinder.setRotationAxis(
            new Point3D( 100, 100, 0)
        );

        PhongMaterial colorMat = new PhongMaterial();
        colorMat.setDiffuseColor(Color.FORESTGREEN);
        colorMat.setSpecularColor(Color.LIMEGREEN);

        cylinder.setMaterial(colorMat);
        cylinder.setDrawMode(DrawMode.LINE);

        AmbientLight ambientLight = new AmbientLight(
            Color.web("0x404040")
        );

        PointLight pointLight = new PointLight(
            Color.web("0xffcc33")
        );
        pointLight.setTranslateX(400);
        pointLight.setTranslateY(300);
        pointLight.setTranslateZ(-200);



        Group root = new Group(
            cylinder,
            ambientLight,
            pointLight
        );

        PerspectiveCamera camera = new PerspectiveCamera(false);
        camera.setTranslateX(0);
        camera.setTranslateY(0);
        camera.setTranslateZ(-500);

        Scene scene = new Scene(root, 640, 480);
        scene.setCamera(camera);

        scene.setOnKeyPressed(
            keyEvent -> {
                switch (keyEvent.getCode()) {
                    case W -> camera.setTranslateZ(
                            camera.getTranslateZ() + 10
                    );
                    case S -> camera.setTranslateZ(
                            camera.getTranslateZ() - 10
                    );
                    case A -> camera.setTranslateY(
                            camera.getTranslateY() + 10
                    );
                    case D -> camera.setTranslateY(
                            camera.getTranslateY() - 10
                    );
                }
            }
        );

        stage.setScene(scene);
        stage.show();
    }
}
