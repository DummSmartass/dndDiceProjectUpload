package WSZYSTKO.WYKLADY.WYKLAD9.ex03;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        String[] colName = {
            "String", "Integer", "Boolean"
        };

        Object[][] data = {
            {"ABC", 3, Boolean.valueOf(false)},
            {"DEF", 4, Boolean.valueOf(true)},
            {"GHI", 5, Boolean.valueOf(false)},
        };

        //ustawienie modeluTabeli(zestawu funkcji działających na Jlistach)
        //nadpisanie funkcji na miesjcu
        DefaultTableModel dtm = new DefaultTableModel()
        {
            //zwraca ilość rekordów
            @Override
            public int getRowCount() {
                return data.length;
            }

            //zwraca ilość kolumn
            @Override
            public int getColumnCount() {
                return data[0].length;
            }

            //zwraca wartość z danego wiersza i określonej kolumny
            @Override
            public Object getValueAt(int row, int column) {
                return data[row][column];
            }

            //zwraca klase obiektów przechowywanych w danej kolumine
            @Override
            public Class<?> getColumnClass(int columnIndex)
            {
                //jeżeli jest to kolumna 2 to jest to klasa Boolean
                return columnIndex == 2 ? Boolean.class : super.getColumnClass(columnIndex);
            }

            // czy indeks jest edytowalny
            @Override
            public boolean isCellEditable(int row, int column)
            {
                //umożliwia próbe wpłynięcia na pole w kolumnie 2
                return column == 2 ? true : false;
            }

            // ustawianie wartości na podanym indeksie
            @Override
            public void setValueAt(Object aValue, int row, int column)
            {
                // pozwala nadać wartość polu w kolumnie 2
                if(column == 2)
                {
                    //toStrig z value pozwala wyciągnąć informacje czy akcja oznaczyła go czy odznaczyła (o i 1)
                    //Boolean.valueOf jest w stanie wyciągnąć z tekstu wartość boolean
                    Boolean bool = Boolean.valueOf(aValue.toString());
                    // zapisanie zmienionej wartosći
                    data[row][column] = bool;
                }
            }
        };

        JTable jTable = new JTable();

        // po ustawieniu elementu typu DefaultTabelModel można wykorzystywać wszystkie jego funkcje
        jTable.setModel(dtm);

        add(jTable);
    }
}
