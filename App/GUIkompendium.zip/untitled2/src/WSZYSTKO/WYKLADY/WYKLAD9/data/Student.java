package WSZYSTKO.WYKLADY.WYKLAD9.data;

public
    class Student {

    private String name;
    private int id;
    private boolean grad;
    private int grade;

    public Student(String name, int id) {
        this.name = name;
        this.id = id;
        this.grad = Math.random() > 0.5;
        this.grade = 5;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public boolean isGrad() {
        return grad;
    }

    public void setGrad(boolean grad) {
        this.grad = grad;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return name+" "+id;
    }

    public static Student[] makeStudents(){
        return new Student[]{
            new Student( "tomaszew", 534),
            new Student( "Jean-Luc", 1701),
            new Student( "Kathrin", 74656),
            new Student( "Benjamin", 9)
        };
    }

}
