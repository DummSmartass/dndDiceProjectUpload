package WSZYSTKO.WYKLADY.WYKLAD9.ex02;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;
import WSZYSTKO.WYKLADY.WYKLAD9.ex01.StudentModel;
import WSZYSTKO.WYKLADY.WYKLAD9.ex01.StudentView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        String[] colName = {
            "String", "Integer", "Boolean"
        };

        //Elementy są typu Object więc każdy z podamych typów może byćzawarty w liście
        Object[][] data =
        {
            // podanie elementów listy jako zbiór tablic o różnych wartosćiach
            {"ABC", 3, false},
            {"DEF", 4, Boolean.valueOf(true)},
            {"GHI", 5, Boolean.valueOf(false)},
        };

        // typ Jtable przystosowany jest do przyjmowania tabeli 2d i wyświetlania jej w oknie
        JTable jTable = new JTable( data, colName);

        add(jTable);
    }
}
