package WSZYSTKO.WYKLADY.WYKLAD9.ex01;

import javax.swing.*;

public
    class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            ()->{
                MyFrame jf = new MyFrame();
                jf.setTitle("w09 Frame");
                jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                jf.setSize( 640, 480);
                jf.setVisible(true);
            }
        );

    }
}
