package WSZYSTKO.WYKLADY.WYKLAD9.ex01;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public
    class MyFrame
    extends JFrame {

    private Student[] students;

    public MyFrame() throws HeadlessException {
        this.students = Student.makeStudents();

        JPanel jp = new JPanel();

        JComboBox<Student> jcb = new JComboBox<>();
        jcb.setModel(
            new StudentModel()
        );
        jcb.setRenderer(
            new ListCellRenderer<Student>() {

                StudentView sv = new StudentView();

                @Override
                public Component getListCellRendererComponent(JList<? extends Student> list, Student value, int index, boolean isSelected, boolean cellHasFocus) {
                    if(value != null)
                        sv.setStudent(value);
                    return sv;
                }
            }
        );


        jp.add(jcb);

        jcb.addItemListener(
            new ItemListener() {
                @Override
                public void itemStateChanged(ItemEvent e) {
                    if(e.getStateChange() == ItemEvent.SELECTED)
                        System.out.println(e);
                }
            }
        );

        add(jp);
    }
}
