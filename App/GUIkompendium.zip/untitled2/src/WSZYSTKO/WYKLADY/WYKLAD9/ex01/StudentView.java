package WSZYSTKO.WYKLADY.WYKLAD9.ex01;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import java.awt.*;

public
    class StudentView
    extends JPanel {

    private JLabel icon;
    private JLabel sNum;
    private JLabel sName;

    public StudentView() {
        icon = new JLabel();
        // label możem mieć nadaną domyślną wielkość
        icon.setPreferredSize(
            new Dimension(50, 100)
        );
        sNum = new JLabel();
        sName = new JLabel();

        this.add( icon);
        this.add( sNum);
        this.add( sName);
    }

    public void setStudent(Student student){
        sNum.setText(""+student.getId());
        sName.setText(student.getName());

        icon.setIcon
        (
            // Jlabel moze przechowywać obrazy
            // obrazy identyfikuje się po icg lokalizacji(jak na obrazku)
            //jeżeli lokalizacja nie istnieje plik się nie wyświetla
            new ImageIcon("C:\\2122L\\wisGUIw\\img\\"+student.getId()+".jpg")
        );
    }
}
