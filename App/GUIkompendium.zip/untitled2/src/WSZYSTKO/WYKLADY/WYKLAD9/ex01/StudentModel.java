package WSZYSTKO.WYKLADY.WYKLAD9.ex01;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import javax.swing.event.ListDataListener;

public
    class StudentModel
    implements ComboBoxModel<Student> {

    private Student[] students;

    // zainicjowanie modelu (w tym przypadku od razu wypełnia danymi)
    public StudentModel() {
        this.students = Student.makeStudents();
    }

    private Object selectedItem;

    @Override
    public void setSelectedItem(Object anItem) {
        selectedItem = anItem;
    }

    @Override
    public Object getSelectedItem() {
        return selectedItem;
    }

    @Override
    public int getSize() {
        return this.students.length;
    }

    @Override
    public Student getElementAt(int index) {
        return this.students[index];
    }

    @Override
    public void addListDataListener(ListDataListener l) {

    }

    @Override
    public void removeListDataListener(ListDataListener l) {

    }
}
