package WSZYSTKO.WYKLADY.WYKLAD9.ex04;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.io.File;

public
    class StudentModel

    //abstractTable model służy do zarządzania jtabelami
    extends AbstractTableModel {

    //Model zawiera dane
    private Student[] students;

    public StudentModel(){
        this.students = Student.makeStudents();

        // Thread randomowo zmienia ocene pierwszego ucznia
        new Thread(
            () -> {
                while(!Thread.currentThread().isInterrupted()){
                    students[0].setGrade((int)(Math.random()*4+1));
                    fireTableCellUpdated( 0, 4);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        ).start();
    }

    @Override
    public int getRowCount() {
        return this.students.length;
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    //model może nadpisać zwracanie nazwy kolumny
    @Override
    public String getColumnName(int columnIndex) {
        return switch (columnIndex){
            case 0 -> "Name";
            case 1 -> "Id";
            case 2 -> "Grad";
            case 3 -> "Icon";
            case 4 -> "Ocena";
            default -> "";
        };
    }

    @Override
    public Class<?> getColumnClass(int columnIndex)
    {
        //warto zauważy, że każdy typ inaczej prezentuje sie w tabeli
        return switch (columnIndex){
            case 1 -> Integer.class;
            case 2 -> Boolean.class;
            case 3 -> ImageIcon.class;
            case 4 -> Integer.class;
            default -> String.class;
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return switch (columnIndex){
            case 2 -> true;
            case 4 -> true;
            default -> false;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Student stud = this.students[rowIndex];

        return switch(columnIndex){
            case 0 -> stud.getName();
            case 1 -> stud.getId();
            case 2 -> stud.isGrad();

            //pobranie wartości w formie pliku graficznego
            case 3 ->
            {
                // zmienna typu plk przyjmuje lokalizacje porządanego pliku(nie mam tego pliku więc sie nie wyświetla)
                File file = new File(
                    ".\\img\\"+stud.getId()+".jpg"
                );
                // ImageIcon wyświetla Icony z plików graficznych

                // yield zwraca element(ikone) w switchu
                yield new ImageIcon
                (
                    // element bęący wynikiem zapytania jest zwracana przez yield
                    file.exists() ? file.toString()/*file.toString jest wymagane bo string jest jedyną wartością jaka może być przyjęta do odczytania pliku*/ : ".\\img\\none.jpg"
                );
            }
            case 4 -> stud.getGrade();
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        switch (columnIndex)
        {
            case 2 ->
            {
                Boolean bool = (Boolean) aValue;

                //ustawiony w tabeli jest element w podanym miejscu
                students[rowIndex].setGrad(bool);
            }
            case 4 ->
            {
                //ustawiony w tabeli jest element w podanym miejscu
                students[rowIndex].setGrade((Integer)aValue);
            }
        };

        // fireTableCellUpdated wywołany na podanym indexie powoduje odświerzenie elementu
        fireTableCellUpdated( rowIndex, columnIndex);
    }
}
