package WSZYSTKO.WYKLADY.WYKLAD9.ex04;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public
    class MyIntegerJPanel
    extends JPanel
    implements TableCellRenderer
    // implements TableCellRenderer pozwala kompoentowi być używany jako renderer
{

    private JLabel lGrade;

    public MyIntegerJPanel(){
        this.lGrade = new JLabel("none");

        //ustawienie layoutu
        this.setLayout(new FlowLayout());

        this.add(lGrade);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
        // renderuje wartoś oceny w zależności od ocey ucznia
        this.lGrade.setText(value.toString());

        // kolor pola typu int są zależny od oceny, i zostaje ustawiony na różny kolor w zależności od podanej oceny
        this.setBackground
        (
            (Integer)value < 3 ? Color.RED : Color.GREEN
        );

        //samo return this wystarczy aby bazwa ewrsja działała, taki jest stan domyślny
        return this;
    }
}
