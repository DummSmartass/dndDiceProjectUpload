package WSZYSTKO.WYKLADY.WYKLAD9.ex04;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public
    class MyIcon
    extends JLabel // rosszerza Jlabel - może być używany jako label
    implements TableCellRenderer // implementuje tableCellRenderer - może renderować
{

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
    //masa danych

        //ustawia icone na typ elemeńcie
        this.setIcon
        (
            //wartość zcastowaną do ImageIcon
            (ImageIcon)value
        );

        //domyślnie zwraca this, i teraz zwraca this
        return this;
    }
}
