package WSZYSTKO.WYKLADY.WYKLAD9.ex04;

import WSZYSTKO.WYKLADY.WYKLAD9.data.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;

public
    class MyFrame
    extends JFrame {



    public MyFrame() throws HeadlessException {

        JTable jTable = new JTable();

        // instancja StudentModel może zastąpić instancje AbstractTableModel, bo StudentModel rozszerza AbstractTableModel
        jTable.setModel(new StudentModel());
        // nie ustawiamy danych są one dodane wewnątrz modelu

        // elementy typu Integer nie dostająrenderea
        jTable.setDefaultRenderer( Integer.class, null);

        //ustawianie customowego renerera dla elementów typu icon
        jTable.setDefaultRenderer
        (
            ImageIcon.class, new MyIcon()
        );

        //ustawianie customowego renerera dla elementów typu MyIntegerJPanel
        jTable.setDefaultRenderer(
            Integer.class, new MyIntegerJPanel()
        );

        //ustawminie Combocoxa i dodanie do niego wszystkich opcji
        JComboBox<Integer> jcb = new JComboBox<>();
        jcb.addItem(2);
        jcb.addItem(3);
        jcb.addItem(4);
        jcb.addItem(5);

        TableColumn tc = jTable.getColumnModel().getColumn(4);
        // zmienna typu kolumny (konkretnie kolumny 4 obecnie niużywanej)

        //ustawienie metody edytowania
        tc.setCellEditor
        (
            //nowy domyślny edytor do którego dostrczony jest argument w postani comboboca za pomocą którego chce ustawiać oceny
            new DefaultCellEditor(jcb)
        );

        // ustawienie wysokości wiersza tabeli na wielkość 100 pikseli
        jTable.setRowHeight(100);

        add(jTable);
    }
}
